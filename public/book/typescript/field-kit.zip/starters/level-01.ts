function palletLabel(crateCount: number): string {
  // Check the count, then round the pallet requirement up.
  throw new Error('Implement palletLabel');
}
