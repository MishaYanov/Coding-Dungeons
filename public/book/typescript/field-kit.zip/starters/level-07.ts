export type Decision =
  | { kind: 'route'; dock: number }
  | { kind: 'invalid'; reason: string };

export function decide(destination: string): Decision {
  throw new Error('Implement decide');
}
