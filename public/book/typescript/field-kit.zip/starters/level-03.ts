type Arrival =
  | { kind: 'assigned'; dock: number }
  | { kind: 'waiting'; reason: string };

function canUnload(
  arrival: Arrival, openDocks: readonly number[]
): boolean {
  throw new Error('Implement canUnload');
}
