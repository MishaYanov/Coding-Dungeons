type Destination = 'north' | 'south';
type Decision =
  | { kind: 'route'; dock: number }
  | { kind: 'duplicate' }
  | { kind: 'conflict' }
  | { kind: 'invalid' };

function handle(value: unknown, seen: Map<string, Destination>): Decision {
  throw new Error('Implement handle');
}
