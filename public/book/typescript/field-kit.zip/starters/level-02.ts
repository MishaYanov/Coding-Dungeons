type Cargo = { readonly id: string; readonly weightKg: number };

function heavyIds(items: readonly Cargo[]): string[] {
  throw new Error('Implement heavyIds');
}
