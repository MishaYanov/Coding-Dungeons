type Job =
  | { state: 'queued'; id: string }
  | { state: 'running'; id: string }
  | { state: 'completed'; id: string };

function unreachable(value: never): never {
  throw new Error(`Unhandled state: ${String(value)}`);
}

function advance(job: Job): Job {
  throw new Error('Implement advance');
}
