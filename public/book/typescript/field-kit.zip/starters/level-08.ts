function pluck<T, K extends keyof T>(
  rows: readonly T[], key: K
): T[K][] {
  throw new Error('Implement pluck');
}
