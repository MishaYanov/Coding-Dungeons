type Dock = { id: string; capacity: number; open: boolean };
type DockPatch = never; // Replace with a type derived from Dock.

function applyPatch(dock: Dock, patch: DockPatch): Dock {
  throw new Error('Implement applyPatch');
}
