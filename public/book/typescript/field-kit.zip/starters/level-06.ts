type Gate = 'open' | 'closed' | 'offline';

async function readGate(readOpen: () => Promise<boolean>): Promise<Gate> {
  throw new Error('Implement readGate');
}
