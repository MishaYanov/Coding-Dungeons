function labelMatching(
  weights: readonly number[],
  label: (weight: number) => string,
): string[] {
  throw new Error('Implement labelMatching');
}
