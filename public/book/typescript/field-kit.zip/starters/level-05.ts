type DockStatus = { dock: number; open: boolean };

function readDockStatus(raw: string): DockStatus | undefined {
  throw new Error('Implement readDockStatus');
}
