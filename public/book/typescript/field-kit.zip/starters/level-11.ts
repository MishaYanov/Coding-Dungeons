type Payloads = {
  arrive: { dock: number };
  depart: { vessel: string };
};
type Notice = {
  [K in keyof Payloads]: { kind: K; payload: Payloads[K] }
}[keyof Payloads];

function announce(notice: Notice): string {
  throw new Error('Implement announce');
}
