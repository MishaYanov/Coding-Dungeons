declare const dockMark: unique symbol;
type DockId = string & { readonly [dockMark]: true };

function parseDockId(value: unknown): DockId | undefined {
  throw new Error('Implement parseDockId');
}
