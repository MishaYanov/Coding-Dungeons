type Probe =
  | { dock: string; ok: true; open: boolean }
  | { dock: string; ok: false; reason: string };

async function probeAll(
  docks: readonly string[], query: (dock: string) => Promise<boolean>,
): Promise<Probe[]> {
  throw new Error('Implement probeAll');
}
