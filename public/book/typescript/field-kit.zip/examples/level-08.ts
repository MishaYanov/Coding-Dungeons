function field<T, K extends keyof T>(record: T, key: K): T[K] {
  return record[key];
}

const dock = { id: 'N-1', capacity: 24 };
const id: string = field(dock, 'id');
const capacity: number = field(dock, 'capacity');
if (id !== 'N-1' || capacity !== 24) throw new Error('Wrong value');
