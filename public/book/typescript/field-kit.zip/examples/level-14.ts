type Destination = 'north' | 'south';
type Command = { id: string; to: Destination };
type Decision =
  | { kind: 'route'; dock: number }
  | { kind: 'duplicate' }
  | { kind: 'conflict' };

function decode(value: unknown): Command | undefined {
  if (typeof value !== 'object' || value === null) return undefined;
  if (Array.isArray(value)) return undefined;
  if (!Object.hasOwn(value, 'id') || !('id' in value)) return undefined;
  if (!Object.hasOwn(value, 'to') || !('to' in value)) return undefined;
  if (typeof value.id !== 'string' || value.id.trim() === '') {
    return undefined;
  }
  if (value.to !== 'north' && value.to !== 'south') return undefined;
  return { id: value.id.trim(), to: value.to };
}

function dispatch(command: Command, seen: Map<string, Destination>): Decision {
  const previous = seen.get(command.id);
  if (previous === command.to) return { kind: 'duplicate' };
  if (previous !== undefined) return { kind: 'conflict' };
  seen.set(command.id, command.to);
  return { kind: 'route', dock: command.to === 'north' ? 1 : 2 };
}
