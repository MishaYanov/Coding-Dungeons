export type Decision =
  | { kind: 'route'; dock: number }
  | { kind: 'invalid'; reason: string };

function normalizeDestination(value: string): string {
  return value.trim().toUpperCase();
}

export function decide(destination: string): Decision {
  switch (normalizeDestination(destination)) {
    case 'NORTH': return { kind: 'route', dock: 1 };
    case 'SOUTH': return { kind: 'route', dock: 2 };
    default: return { kind: 'invalid', reason: 'Unknown destination' };
  }
}

const decision = decide(' south ');
if (decision.kind !== 'route' || decision.dock !== 2) {
  throw new Error('Wrong dock');
}
