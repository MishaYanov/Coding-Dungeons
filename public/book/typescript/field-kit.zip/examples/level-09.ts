type Dock = { id: string; capacity: number; open: boolean };
type EditableKey = Exclude<keyof Dock, 'id'>;
type DockPatch = { [K in EditableKey]?: Dock[K] };

const defaultDocks = {
  north: { capacity: 24 },
  south: { capacity: 12 },
} as const satisfies Record<'north' | 'south', { capacity: number }>;

function applyPatch(dock: Dock, patch: DockPatch): Dock {
  return {
    id: dock.id,
    capacity: patch.capacity ?? dock.capacity,
    open: patch.open ?? dock.open,
  };
}

const cap: 24 = defaultDocks.north.capacity;
const next = applyPatch({ id: 'N', capacity: cap, open: true }, { open: false });
if (next.open) throw new Error('Dock was not closed');
