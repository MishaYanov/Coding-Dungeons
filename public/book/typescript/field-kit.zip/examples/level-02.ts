type Cargo = {
  readonly id: string;
  readonly weightKg: number;
};

function totalWeight(items: readonly Cargo[]): number {
  let total = 0;
  for (const item of items) total += item.weightKg;
  return total;
}

const manifest = [
  { id: 'A-1', weightKg: 12, owner: 'Ferry Office' },
  { id: 'A-2', weightKg: 8, owner: 'Warehouse' },
];
if (totalWeight(manifest) !== 20) throw new Error('Bad total');
