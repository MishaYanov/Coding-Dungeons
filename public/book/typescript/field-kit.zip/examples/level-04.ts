type Cargo = { weightKg: number };

function countMatching(
  items: readonly Cargo[],
  matches: (cargo: Cargo) => boolean,
  maximum?: number,
): number {
  if (maximum !== undefined &&
      (!Number.isSafeInteger(maximum) || maximum < 0)) {
    throw new RangeError('Invalid maximum');
  }
  const limit = maximum ?? Infinity;
  let count = 0;
  for (const item of items) {
    if (count >= limit) break;
    if (matches(item)) count++;
  }
  return count;
}

const cargo = [{ weightKg: 12 }, { weightKg: 3 }];
const count = countMatching(cargo, item => item.weightKg > 10, 0);
if (count !== 0) throw new Error('Limit of zero was lost');
