type Manifest = { id: string; weightKg: number };

function readManifest(raw: string): Manifest | undefined {
  let value: unknown;
  try {
    value = JSON.parse(raw);
  } catch {
    return undefined;
  }
  if (typeof value !== 'object' || value === null) return undefined;
  if (Array.isArray(value)) return undefined;
  if (!('id' in value) || !Object.hasOwn(value, 'id')) return undefined;
  if (!('weightKg' in value) || !Object.hasOwn(value, 'weightKg')) {
    return undefined;
  }
  const { id, weightKg } = value;
  if (typeof id !== 'string' || id.trim() === '') return undefined;
  if (typeof weightKg !== 'number') return undefined;
  if (!Number.isFinite(weightKg) || weightKg < 0) return undefined;
  return { id: id.trim(), weightKg };
}

if (!readManifest('{"id":"C-4","weightKg":20}')) {
  throw new Error('Valid manifest rejected');
}
