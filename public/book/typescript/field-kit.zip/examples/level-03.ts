type Arrival =
  | { kind: 'assigned'; dock: number }
  | { kind: 'waiting'; reason: string };

function statusText(arrival: Arrival): string {
  if (arrival.kind === 'assigned') {
    return `Dock ${arrival.dock}`;
  }
  return `Waiting: ${arrival.reason}`;
}

const status = statusText({ kind: 'assigned', dock: 0 });
if (status !== 'Dock 0') throw new Error(status);
