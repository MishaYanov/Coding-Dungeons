type Job =
  | { state: 'queued'; id: string }
  | { state: 'running'; id: string }
  | { state: 'completed'; id: string };

function unreachable(value: never): never {
  throw new Error(`Unhandled state: ${String(value)}`);
}

function advance(job: Job): Job {
  switch (job.state) {
    case 'queued': return { state: 'running', id: job.id };
    case 'running': return { state: 'completed', id: job.id };
    case 'completed': return job;
    default: return unreachable(job);
  }
}

if (advance({ state: 'queued', id: 'J-2' }).state !== 'running') {
  throw new Error('Wrong transition');
}
