function cargoLabel(count: number, unitMass: number): string {
  if (!Number.isSafeInteger(count) || count < 0) {
    throw new RangeError('Invalid cargo count');
  }
  if (!Number.isFinite(unitMass) || unitMass < 0) {
    throw new RangeError('Invalid unit mass');
  }
  const mass = count * unitMass;
  if (!Number.isFinite(mass)) throw new RangeError('Mass overflow');
  return `${count} units, ${mass} kg`;
}

const label = cargoLabel(3, 2.5);
if (label !== '3 units, 7.5 kg') throw new Error(label);
