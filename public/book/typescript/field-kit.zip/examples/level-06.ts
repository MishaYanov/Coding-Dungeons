type TideReport =
  | { ok: true; heightCm: number }
  | { ok: false; message: string };

async function reportTide(
  readHeight: () => Promise<number>,
): Promise<TideReport> {
  try {
    const heightCm = await readHeight();
    return { ok: true, heightCm };
  } catch {
    return { ok: false, message: 'Tide report unavailable' };
  }
}

const report = reportTide(async () => 0);
report.then(result => {
  if (!result.ok || result.heightCm !== 0) throw new Error('Bad report');
});
