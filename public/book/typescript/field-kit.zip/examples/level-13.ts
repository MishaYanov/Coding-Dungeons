declare const shipmentMark: unique symbol;
type ShipmentId = string & { readonly [shipmentMark]: true };

function parseShipmentId(value: unknown): ShipmentId | undefined {
  if (typeof value !== 'string' || !/^S-[0-9]{4}$/.test(value)) {
    return undefined;
  }
  return value as ShipmentId;
}

function labelFor(id: ShipmentId): string {
  return `Shipment ${id}`;
}

const id = parseShipmentId('S-0042');
if (!id || labelFor(id) !== 'Shipment S-0042') {
  throw new Error('Invalid identifier');
}
