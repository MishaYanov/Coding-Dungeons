type Payloads = {
  arrive: { dock: number };
  depart: { vessel: string };
};
type Notice = {
  [K in keyof Payloads]: { kind: K; payload: Payloads[K] }
}[keyof Payloads];

function announce(notice: Notice): string {
  switch (notice.kind) {
    case 'arrive': return `Dock ${notice.payload.dock} occupied`;
    case 'depart': return `${notice.payload.vessel} departed`;
    default: {
      const missed: never = notice;
      throw new Error(`Unhandled notice: ${String(missed)}`);
    }
  }
}

const text = announce({ kind: 'depart', payload: { vessel: 'Gull' } });
if (text !== 'Gull departed') throw new Error(text);
