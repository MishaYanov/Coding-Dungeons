type Probe =
  | { dock: string; ok: true; open: boolean }
  | { dock: string; ok: false; reason: string };

async function probeOne(
  dock: string, query: (dock: string) => Promise<boolean>,
): Promise<Probe> {
  try {
    return { dock, ok: true, open: await query(dock) };
  } catch {
    return { dock, ok: false, reason: 'Unavailable' };
  }
}

function probeAll(
  docks: readonly string[], query: (dock: string) => Promise<boolean>,
): Promise<Probe[]> {
  return Promise.all(docks.map(dock => probeOne(dock, query)));
}
