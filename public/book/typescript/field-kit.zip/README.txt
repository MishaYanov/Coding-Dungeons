Ferrum World 2 / TypeScript
TypeScript | Signal Harbor

With TypeScript installed, check a worked example with tsc --strict --target ES2022 --noEmit examples/level-01.ts.

Use the starter files to try each challenge. The book has hints, debriefs, and side quests.
