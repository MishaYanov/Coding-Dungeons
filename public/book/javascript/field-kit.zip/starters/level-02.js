function readLimit(raw, fallback) {
  // Handle missing input before converting or checking the number.
  return fallback;
}
