function leaderboard(players) {
  // Select into a new array, sort, and project to names.
  return [];
}
