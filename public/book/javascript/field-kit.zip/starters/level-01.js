function makeBadge(rawName) {
  // Normalize the name and build the record.
  return { name: rawName, visits: 0 };
}
