function setTheme(profile, theme) {
  // Copy the records along the path to theme.
  return { ...profile };
}
