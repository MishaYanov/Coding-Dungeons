function decodeItem(text) {
  const value = JSON.parse(text);
  // Validate record and fields, then normalize the ID.
  return null;
}
