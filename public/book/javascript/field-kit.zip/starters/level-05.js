function pendingSummary(tasks) {
  let count = 0;
  let minutes = 0;
  // Update both totals for unfinished tasks.
  return { count, minutes };
}
