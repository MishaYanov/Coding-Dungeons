function parseCount(text) {
  let value;
  // Parse with a narrow catch. Validate outside that catch.
  return { ok: true, value };
}
