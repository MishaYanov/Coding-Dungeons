function quantitiesFor(shipments, id) {
  const quantities = [];
  // Inspect each shipment and append matching quantities.
  return quantities;
}
