async function runQueue(tasks, limit) {
  // Validate the limit, then create workers that share a next index.
  return [];
}
