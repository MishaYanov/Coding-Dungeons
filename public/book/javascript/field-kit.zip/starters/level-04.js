function shippingCents(subtotalCents, delivery = 'standard') {
  // Handle express and the free standard shipping boundary.
  return 500;
}
