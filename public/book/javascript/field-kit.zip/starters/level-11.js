async function loadInOrder(ids, load) {
  // Start all independent operations and collect their results.
  return [];
}
