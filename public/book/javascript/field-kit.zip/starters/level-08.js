function makeTicketDispenser(prefix) {
  let count = 0;
  return {
    next() { /* Update count and format the ticket. */ },
    issued() { return count; },
  };
}
