function makeRecorder(ledger) {
  // Return a callback that keeps the correct receiver.
  return ledger.add;
}
