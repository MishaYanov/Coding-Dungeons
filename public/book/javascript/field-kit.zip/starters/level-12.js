function makeLatest(load, publish) {
  let current;
  return async function run(query) {
    // Store a new token and form an outcome after the load.
  };
}
