Ferrum World 1 / JavaScript
The JavaScript Workshop

Run a worked example with node examples/level-01.js.

Use the starter files to try each challenge. The book has hints, debriefs, and side quests.
