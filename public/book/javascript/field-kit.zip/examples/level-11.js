function later(value, delay) {
  return new Promise(resolve => setTimeout(() => resolve(value), delay));
}
const first = later('first input', 20);
const second = later('second input', 0);
Promise.all([first, second])
  .then(values => console.log(values.join(' | ')))
  .catch(error => console.error(error));
console.log('Both operations started');
// Both operations started
// first input | second input
