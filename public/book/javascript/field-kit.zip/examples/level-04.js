function lineTotal(unitCents, count = 1) {
  return unitCents * count;
}
function invoiceLabel(unitCents, count) {
  const cents = lineTotal(unitCents, count);
  return cents + ' cents';
}
console.log(invoiceLabel(275, 3)); // 825 cents
console.log(lineTotal(275), lineTotal(275, 0)); // 275 0
