const before = { id: 'P7', settings: { theme: 'light' }, tags: ['saved'] };
const after = {
  ...before,
  settings: { ...before.settings, theme: 'dark' },
};
console.log(before.settings.theme, after.settings.theme); // light dark
console.log(before.tags === after.tags); // true
const byId = new Map([[after.id, after]]);
console.log(byId.get('P7') === after); // true
