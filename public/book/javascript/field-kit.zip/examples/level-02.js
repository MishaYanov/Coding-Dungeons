const savedVolume = 0;
const retryLimit = undefined;
console.log(savedVolume || 50); // 50
console.log(savedVolume ?? 50); // 0
console.log(retryLimit ?? 3); // 3
console.log('7' === 7, Number('7') === 7); // false true
console.log(Number.isFinite(Number('oops'))); // false
