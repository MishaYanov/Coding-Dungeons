const ledger = {
  total: 0,
  add(amount) {
    this.total += amount;
    return this.total;
  },
};
function apply(operation, amount) {
  return operation(amount);
}
const addToLedger = ledger.add.bind(ledger);
console.log(apply(addToLedger, 7)); // 7
console.log(ledger.total); // 7
