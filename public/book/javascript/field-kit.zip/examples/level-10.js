const jobs = [
  { id: 'D', priority: 2, active: true },
  { id: 'A', priority: 10, active: true },
  { id: 'F', priority: 1, active: false },
];
const active = jobs.filter(job => job.active);
active.sort((a, b) => b.priority - a.priority);
const ids = active.map(job => job.id);
console.log(ids.join(',')); // A,D
console.log(jobs[0].id); // D
