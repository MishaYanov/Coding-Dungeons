const shipments = [
  { id: 'A1', quantity: 3 },
  { id: 'B4', quantity: 0 },
];
function findShipment(id) {
  return shipments.find(shipment => shipment.id === id) ?? null;
}
const shipment = findShipment('B4');
const key = 'quantity';
console.log(Object.hasOwn(shipment, key), shipment[key]); // true 0
console.log(findShipment('X0')); // null
