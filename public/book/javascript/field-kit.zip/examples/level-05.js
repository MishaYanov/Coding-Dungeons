const tasks = [
  { done: true, minutes: 10 },
  { done: false, minutes: 20 },
  { done: false, minutes: 0 },
];
let pendingMinutes = 0;
for (const task of tasks) {
  if (task.done) continue;
  pendingMinutes += task.minutes;
}
console.log(pendingMinutes); // 20
