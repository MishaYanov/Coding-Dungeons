function makeCounter(start = 0) {
  let count = start;
  return {
    increment: () => ++count,
    read: () => count,
  };
}
const first = makeCounter();
const second = makeCounter(10);
console.log(first.increment(), first.increment()); // 1 2
console.log(second.read()); // 10
