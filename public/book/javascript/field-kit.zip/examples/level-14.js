async function collectLimited(items, limit, work) {
  if (!Number.isInteger(limit) || limit < 1) throw new RangeError('limit');
  const results = new Array(items.length);
  let cursor = 0;
  async function worker() {
    while (cursor < items.length) {
      const index = cursor++;
      try {
        results[index] = { ok: true, value: await work(items[index]) };
      } catch (error) {
        results[index] = { ok: false, error };
      }
    }
  }
  const size = Math.min(limit, items.length);
  await Promise.all(Array.from({ length: size }, () => worker()));
  return results;
}
collectLimited([2, 3, 4], 2, async n => n * n)
  .then(results => console.log(results.map(result => result.value))); // [4, 9, 16]
