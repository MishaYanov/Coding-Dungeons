function parseProfile(text) {
  const value = JSON.parse(text);
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    return null;
  }
  if (!Object.hasOwn(value, 'name') || typeof value.name !== 'string') {
    return null;
  }
  const name = value.name.trim();
  return name === '' ? null : { name };
}
console.log(parseProfile('{"name":"  Lina  ","extra":true}')); // { name: 'Lina' }
console.log(parseProfile('[]')); // null
