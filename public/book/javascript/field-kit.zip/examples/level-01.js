const raw = '  dana  ';
const displayName = raw.trim().toUpperCase();
let visits = 0;
visits += 1;
const badge = { name: displayName, visits };
badge.visits += 1;
console.log(raw.length, badge.name, badge.visits); // 8 DANA 2
