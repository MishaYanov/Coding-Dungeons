function latestOnly(load, publish) {
  let current;
  return async query => {
    const mine = Symbol();
    current = mine;
    let outcome;
    try {
      outcome = { ok: true, value: await load(query) };
    } catch (error) {
      outcome = { ok: false, error };
    }
    if (mine === current) publish(outcome);
  };
}
const load = async query => {
  if (query === 'old') throw new Error('Old request failed');
  return query;
};
const search = latestOnly(load, outcome => console.log(outcome));
Promise.all([search('old'), search('new')]);
// { ok: true, value: 'new' }
