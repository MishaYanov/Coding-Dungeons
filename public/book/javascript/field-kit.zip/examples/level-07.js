function readJson(text) {
  try {
    return { ok: true, value: JSON.parse(text) };
  } catch (error) {
    if (!(error instanceof SyntaxError)) throw error;
    return { ok: false, reason: 'syntax' };
  }
}
const good = readJson('0');
const bad = readJson('{');
if (!good.ok || good.value !== 0) throw new Error('Expected zero');
if (bad.ok || bad.reason !== 'syntax') throw new Error('Expected syntax error');
console.log('Both checks passed');
