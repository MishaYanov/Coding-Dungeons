fn main() {
    let mut input = String::from("mode=fast");
    let value = input.split_once('=').unwrap().1;
    input.push_str("\nnext=slow");
    println!("{value}");
}
