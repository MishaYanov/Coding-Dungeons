struct Buffer(Vec<u8>);

impl Buffer {
    fn view(&mut self) -> &mut [u8] {
        &mut self.0
    }
}

fn main() {
    let mut buffer = Buffer(vec![1, 2, 3]);
    let first = buffer.view();
    let second = buffer.view();
    first[0] += second[0];
}
