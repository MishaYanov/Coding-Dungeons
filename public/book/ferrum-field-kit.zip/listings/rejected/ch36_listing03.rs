struct ReadOnly;
struct Writable;

struct Store<State> {
    values: Vec<u32>,
    state: std::marker::PhantomData<State>,
}

impl Store<Writable> {
    fn append(&mut self, value: u32) {
        self.values.push(value);
    }
}

fn main() {
    let mut store = Store::<ReadOnly> {
        values: vec![],
        state: std::marker::PhantomData,
    };
    store.append(3);
}
