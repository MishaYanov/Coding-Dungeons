use std::marker::PhantomPinned;

struct Fixed {
    _pinned: PhantomPinned,
}

fn main() {
    let mut value = Box::pin(Fixed { _pinned: PhantomPinned });
    let ordinary: &mut Fixed = value.as_mut().get_mut();
    let replacement = Fixed { _pinned: PhantomPinned };
    let _old = std::mem::replace(ordinary, replacement);
}
