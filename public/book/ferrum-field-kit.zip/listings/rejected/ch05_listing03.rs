fn overwrite<'a>(slot: &mut &'static str, incoming: &'a str) {
    *slot = incoming;
}

fn main() {
    let mut slot: &'static str = "permanent";
    let temporary = String::from("temporary");
    overwrite(&mut slot, &temporary);
}
