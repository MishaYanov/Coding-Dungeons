use std::fmt::{self, Display};

impl Display for Vec<u32> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{} values", self.len())
    }
}
