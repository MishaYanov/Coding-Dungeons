use std::thread;

fn main() {
    let text = String::from("borrowed");
    let view = text.as_str();
    let handle = thread::spawn(move || view.len());
    assert_eq!(handle.join().unwrap(), 8);
}
