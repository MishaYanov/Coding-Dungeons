fn append_length(values: &mut Vec<usize>, length: usize) {
    values.push(length);
}

fn main() {
    let mut values = vec![1, 2];
    append_length(&mut values, values.len());
}
