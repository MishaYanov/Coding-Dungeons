fn extended<const N: usize>() -> [u8; N + 1] {
    [0; N + 1]
}
