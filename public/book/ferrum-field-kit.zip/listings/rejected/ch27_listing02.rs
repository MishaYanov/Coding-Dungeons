trait Lookup {
    async fn find(&self, key: &str) -> Option<String>;
}

fn use_erased(_lookup: &dyn Lookup) {}

fn main() {}
