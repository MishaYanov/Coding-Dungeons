struct Envelope {
    payload: String,
}

impl Drop for Envelope {
    fn drop(&mut self) {
        println!("dropping {} bytes", self.payload.len());
    }
}

fn main() {
    let envelope = Envelope {
        payload: String::from("data"),
    };
    let payload = envelope.payload;
    println!("{payload}");
}
