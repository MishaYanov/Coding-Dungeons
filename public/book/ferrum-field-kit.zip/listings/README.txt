Understanding Rust example companion

This archive accompanies the 42 chapter book Understanding Rust.
Files retain the chapter and listing numbers printed in the book.

Compiler validation
  rustc 1.99.1 (58cf8f9c3 2026-10-13); rustc 1.100.0 (0ef1bc386 2026-11-09)
  Edition 2024
  147 accepted Rust source units type-checked successfully
  12 intentionally rejected source units failed as expected
  0 unexpected compiler outcomes
  127 executable examples and regression suites ran successfully

The validation compiled source units as libraries with --emit=metadata.
This checks types without requiring a main function or a foreign linker.
It is not a runtime test of every listing or a proof of soundness.
The executed examples and regression suites are identified in validation.json.

Check an accepted source unit from the extracted archive

  rustc --edition=2024 --crate-type=lib --emit=metadata examples/ch09_listing01.rs

Run a complete source unit that defines main

  rustc --edition=2024 examples/ch38_listing01.rs -o example.exe
  ./example.exe

Rejected examples are stored under rejected/ and intentionally do not compile.
Read the surrounding chapter for the reason and the intended correction.

The sketches/ directory contains nonstandalone excerpts, manifests, commands,
and diagrams. These were not classified as compilable Rust source units.
The surrounding book explains the required context and assumptions.

index.tsv maps every listing to its chapter, classification, and archive path.
validation.json records the check outcomes without local workspace paths.

This companion uses no Cargo dependencies for its standalone checked units.
The lab_async, lab_dispatch and lab_schedules programs are complete host labs.
Use index.tsv to find their examples/ filenames. Compile one file at a time.
The async lab uses host threads and a controlled logical clock; it does not
claim to be a production I/O runtime. The schedule lab explores a stated model,
not every hardware memory ordering or possible Rust execution.
Foreign integration and runtime excerpts may need the context described in
the book before they can be linked or used in a complete application.
