use std::cell::Cell;
use std::future::Future;
use std::pin::pin;
use std::rc::Rc;
use std::task::{Context, Poll, Waker};

struct Token(Rc<Cell<usize>>);

impl Drop for Token {
    fn drop(&mut self) {
        self.0.set(self.0.get() + 1);
    }
}

async fn use_token(_token: Token) -> u32 {
    7
}

fn main() {
    let drops = Rc::new(Cell::new(0));
    let future = use_token(Token(Rc::clone(&drops)));
    assert_eq!(drops.get(), 0);
    drop(future);
    assert_eq!(drops.get(), 1);

    let mut ready = pin!(async { 12_u32 });
    let mut context = Context::from_waker(Waker::noop());
    assert_eq!(ready.as_mut().poll(&mut context), Poll::Ready(12));
}
