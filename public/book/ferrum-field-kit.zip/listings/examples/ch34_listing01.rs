fn main() {
    let mut values = Vec::with_capacity(8);
    values.extend([10, 20, 30]);
    let capacity = values.capacity();
    values.clear();
    assert!(values.is_empty());
    assert_eq!(values.capacity(), capacity);

    values.extend([7, 8]);
    assert_eq!(values, [7, 8]);
}
