struct Compact;
struct Verbose;

trait Render<Policy> {
    fn render(&self) -> String;
}

struct Task {
    id: u64,
    title: String,
}

impl Render<Compact> for Task {
    fn render(&self) -> String {
        self.id.to_string()
    }
}

impl Render<Verbose> for Task {
    fn render(&self) -> String {
        format!("task {} {}", self.id, self.title)
    }
}

fn render<T, P>(value: &T) -> String
where
    T: Render<P>,
{
    <T as Render<P>>::render(value)
}

fn main() {
    let task = Task { id: 7, title: "rebuild index".into() };
    assert_eq!(render::<_, Compact>(&task), "7");
    assert_eq!(render::<_, Verbose>(&task), "task 7 rebuild index");
}
