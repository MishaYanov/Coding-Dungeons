struct Work {
    payload: String,
    retries: u32,
}

fn main() {
    let work = Work {
        payload: "rebuild".into(),
        retries: 3,
    };

    let consume_payload = move || work.payload;
    assert_eq!(work.retries, 3);
    assert_eq!(consume_payload(), "rebuild");
}
