use std::collections::HashMap;
use std::sync::Arc;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
struct Symbol(usize);

struct Interner {
    by_text: HashMap<Arc<str>, Symbol>,
    texts: Vec<Arc<str>>,
}

impl Interner {
    fn new() -> Self {
        Self { by_text: HashMap::new(), texts: Vec::new() }
    }

    fn intern(&mut self, text: &str) -> Symbol {
        if let Some(&symbol) = self.by_text.get(text) {
            return symbol;
        }
        let symbol = Symbol(self.texts.len());
        let owned: Arc<str> = Arc::from(text);
        self.texts.push(Arc::clone(&owned));
        self.by_text.insert(owned, symbol);
        symbol
    }

    fn resolve(&self, symbol: Symbol) -> Option<&str> {
        self.texts.get(symbol.0).map(AsRef::as_ref)
    }

    fn shared_text(&self, symbol: Symbol) -> Option<Arc<str>> {
        self.texts.get(symbol.0).cloned()
    }
}

fn main() {
    let mut interner = Interner::new();
    let first = interner.intern("parser");
    let second = interner.intern("parser");
    let third = interner.intern("scheduler");
    assert_eq!(first, second);
    assert_ne!(first, third);
    assert_eq!(interner.resolve(first), Some("parser"));
    let retained = interner.shared_text(first).unwrap();
    drop(interner);
    assert_eq!(&*retained, "parser");
}
