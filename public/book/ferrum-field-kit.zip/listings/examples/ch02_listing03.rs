struct Trace(&'static str);

impl Drop for Trace {
    fn drop(&mut self) {
        println!("release {}", self.0);
    }
}

fn consume(value: Trace) {
    println!("consume {}", value.0);
}

fn run(send_first: bool) {
    let first = Trace("first");
    let second = Trace("second");
    if send_first {
        consume(first);
    }
    println!("still have {}", second.0);
}

fn main() {
    run(true);
    run(false);
}
