fn selected<'a, 'b>(
    values: &'a [u32],
    _label: &'b str,
) -> impl Iterator<Item = &'a u32> + use<'a> {
    values.iter().filter(|value| **value % 2 == 0)
}

fn main() {
    let values = [1, 2, 3, 4];
    let iter;
    {
        let label = String::from("even");
        iter = selected(&values, &label);
    }
    assert_eq!(iter.copied().collect::<Vec<_>>(), [2, 4]);
}
