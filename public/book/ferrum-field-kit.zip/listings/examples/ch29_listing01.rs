use std::mem::{align_of, offset_of, size_of};

#[repr(C)]
struct Header {
    kind: u8,
    length: u32,
    flags: u16,
}

fn main() {
    assert_eq!(offset_of!(Header, kind), 0);
    assert_eq!(offset_of!(Header, length) % align_of::<u32>(), 0);
    assert_eq!(offset_of!(Header, flags) % align_of::<u16>(), 0);
    assert_eq!(size_of::<Header>() % align_of::<Header>(), 0);
    println!("size {} alignment {}", size_of::<Header>(),
        align_of::<Header>());
}
