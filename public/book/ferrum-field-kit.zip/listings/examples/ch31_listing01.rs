fn pair_mut<T>(
    values: &mut [T],
    left: usize,
    right: usize,
) -> Option<(&mut T, &mut T)> {
    if left == right || left >= values.len() || right >= values.len() {
        return None;
    }
    let pointer = values.as_mut_ptr();
    // SAFETY: each index selects an initialized in bounds element.
    // Distinct indices denote disjoint logical elements. Both borrows
    // are tied to the exclusive input slice and no other access is used.
    unsafe {
        Some((&mut *pointer.add(left), &mut *pointer.add(right)))
    }
}

fn main() {
    let mut values = [10, 20, 30];
    let (left, right) = pair_mut(&mut values, 2, 0).unwrap();
    *left += 1;
    *right += 2;
    assert_eq!(values, [12, 20, 31]);
    assert!(pair_mut(&mut values, 1, 1).is_none());
    assert!(pair_mut(&mut values, 0, 3).is_none());
}
