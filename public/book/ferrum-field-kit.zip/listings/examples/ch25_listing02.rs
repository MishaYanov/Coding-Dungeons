use std::future::Future;
use std::pin::Pin;
use std::sync::{Arc, Mutex};
use std::task::{Context, Poll, Waker};

struct Shared<T> {
    value: Option<T>,
    waiter: Option<Waker>,
}

struct Completion<T>(Arc<Mutex<Shared<T>>>);
struct Promise<T>(Arc<Mutex<Shared<T>>>);

fn completion_pair<T>() -> (Completion<T>, Promise<T>) {
    let shared = Arc::new(Mutex::new(Shared {
        value: None,
        waiter: None,
    }));
    (Completion(Arc::clone(&shared)), Promise(shared))
}

impl<T> Completion<T> {
    fn complete(self, value: T) {
        let waiter = {
            let mut shared = self.0.lock().unwrap();
            shared.value = Some(value);
            shared.waiter.take()
        };
        if let Some(waiter) = waiter {
            waiter.wake();
        }
    }
}

impl<T> Future for Promise<T> {
    type Output = T;

    fn poll(
        self: Pin<&mut Self>,
        context: &mut Context<'_>,
    ) -> Poll<T> {
        let next = context.waker().clone();
        let mut shared = self.0.lock().unwrap();
        if let Some(value) = shared.value.take() {
            return Poll::Ready(value);
        }
        let previous = shared.waiter.replace(next);
        drop(shared);
        drop(previous);
        Poll::Pending
    }
}
