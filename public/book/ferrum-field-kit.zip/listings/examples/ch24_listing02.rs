use std::pin::Pin;

fn reset(mut value: Pin<&mut u32>) {
    *value.as_mut().get_mut() = 0;
}

fn main() {
    let mut value = 9_u32;
    reset(Pin::new(&mut value));
    assert_eq!(value, 0);
}
