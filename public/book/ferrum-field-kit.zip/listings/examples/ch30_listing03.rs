fn replace_string(slot: &mut String, incoming: String) -> String {
    let pointer: *mut String = slot;
    // SAFETY: the exclusive borrow supplies one initialized String
    // place. replace leaves incoming there and returns the old owner.
    unsafe { pointer.replace(incoming) }
}

fn main() {
    let mut value = String::from("before");
    let old = replace_string(&mut value, String::from("after"));
    assert_eq!(old, "before");
    assert_eq!(value, "after");
}
