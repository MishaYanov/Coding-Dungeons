struct AppendTransaction<'a> {
    target: &'a mut Vec<u32>,
    original_len: usize,
    committed: bool,
}

impl<'a> AppendTransaction<'a> {
    fn new(target: &'a mut Vec<u32>) -> Self {
        let original_len = target.len();
        Self { target, original_len, committed: false }
    }

    fn commit(mut self) {
        self.committed = true;
    }
}

impl Drop for AppendTransaction<'_> {
    fn drop(&mut self) {
        if !self.committed {
            self.target.truncate(self.original_len);
        }
    }
}

fn append(
    target: &mut Vec<u32>,
    values: &[u32],
    fail_after: Option<usize>,
) -> Result<(), &'static str> {
    let transaction = AppendTransaction::new(target);
    for (index, &value) in values.iter().enumerate() {
        if fail_after == Some(index) {
            return Err("injected failure");
        }
        transaction.target.push(value);
    }
    transaction.commit();
    Ok(())
}

fn main() {
    for stage in 0..3 {
        let mut target = vec![9];
        assert!(append(&mut target, &[1, 2, 3], Some(stage)).is_err());
        assert_eq!(target, vec![9]);
    }
    let mut target = vec![9];
    append(&mut target, &[1, 2, 3], None).unwrap();
    assert_eq!(target, vec![9, 1, 2, 3]);
}
