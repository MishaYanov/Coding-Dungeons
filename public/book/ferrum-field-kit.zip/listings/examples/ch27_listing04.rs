use std::future::Future;
use std::pin::Pin;
use std::task::{Context, Poll, Waker};

type Operation<'a, T> =
    Pin<Box<dyn Future<Output = T> + Send + 'a>>;

trait Reader: Send + Sync {
    fn length(&self) -> Operation<'_, usize>;
}

struct MemoryReader {
    bytes: Vec<u8>,
}

impl Reader for MemoryReader {
    fn length(&self) -> Operation<'_, usize> {
        Box::pin(async move { self.bytes.len() })
    }
}

fn main() {
    let reader: Box<dyn Reader> = Box::new(MemoryReader {
        bytes: vec![4, 5, 6],
    });
    let mut operation = reader.length();
    let mut context = Context::from_waker(Waker::noop());
    assert_eq!(operation.as_mut().poll(&mut context), Poll::Ready(3));
}
