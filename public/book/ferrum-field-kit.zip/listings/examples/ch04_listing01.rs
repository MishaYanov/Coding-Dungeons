fn value_for<'record>(
    record: &'record str,
    wanted: &str,
) -> Option<&'record str> {
    for field in record.split(';') {
        let (key, value) = field.split_once('=')?;
        if key.trim() == wanted {
            return Some(value.trim());
        }
    }
    None
}

fn main() {
    let record = String::from("mode=strict;limit=20");
    let result;
    {
        let key = String::from("mode");
        result = value_for(&record, &key).unwrap();
    }
    assert_eq!(result, "strict");
}
