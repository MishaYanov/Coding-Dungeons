/// Borrows bytes supplied by an external owner.
///
/// # Safety
/// For the complete returned lifetime, pointer must be nonnull and
/// valid for reads of length initialized bytes in one allocation.
/// The range must fit isize::MAX and must not be mutated except as
/// permitted by Rust's shared reference rules.
unsafe fn borrowed_bytes<'a>(
    pointer: *const u8,
    length: usize,
) -> &'a [u8] {
    // SAFETY: these are precisely the caller's obligations above.
    unsafe { std::slice::from_raw_parts(pointer, length) }
}

fn main() {
    let bytes = [1_u8, 2, 3];
    // SAFETY: bytes remains alive and unchanged through this use;
    // its pointer and length describe one initialized allocation.
    let view = unsafe { borrowed_bytes(bytes.as_ptr(), bytes.len()) };
    assert_eq!(view, &[1, 2, 3]);
}
