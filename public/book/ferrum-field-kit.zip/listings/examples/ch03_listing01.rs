fn main() {
    let mut names = vec![String::from("one")];
    let first = &names[0];
    assert_eq!(first.len(), 3);
    names.push(String::from("two"));
    assert_eq!(names.len(), 2);
}
