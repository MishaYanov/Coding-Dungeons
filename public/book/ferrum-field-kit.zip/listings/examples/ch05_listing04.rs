fn length(text: &str) -> usize {
    text.len()
}

fn accepts_static_only(operation: fn(&'static str) -> usize) -> usize {
    operation("permanent input")
}

fn main() {
    assert_eq!(accepts_static_only(length), 15);
}
