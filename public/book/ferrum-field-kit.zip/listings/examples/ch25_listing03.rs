use std::future::Future;
use std::pin::Pin;
use std::task::{Context, Poll};

struct SumRange {
    next: u64,
    end: u64,
    sum: u64,
}

impl Future for SumRange {
    type Output = u64;

    fn poll(
        mut self: Pin<&mut Self>,
        context: &mut Context<'_>,
    ) -> Poll<u64> {
        for _ in 0..128 {
            if self.next >= self.end {
                return Poll::Ready(self.sum);
            }
            self.sum = self.sum.wrapping_add(self.next);
            self.next += 1;
        }
        context.waker().wake_by_ref();
        Poll::Pending
    }
}
