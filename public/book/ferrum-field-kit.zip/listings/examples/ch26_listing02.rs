#[derive(Debug, PartialEq)]
struct Receipt {
    index: usize,
}

struct Prepared {
    record: String,
}

struct Ledger {
    records: Vec<String>,
}

impl Prepared {
    fn validate(record: String) -> Result<Self, &'static str> {
        if record.trim().is_empty() {
            return Err("empty record");
        }
        Ok(Self { record })
    }

    fn commit(self, ledger: &mut Ledger) -> Receipt {
        let index = ledger.records.len();
        ledger.records.push(self.record);
        Receipt { index }
    }
}

async fn prepare(record: String) -> Result<Prepared, &'static str> {
    std::future::ready(()).await;
    Prepared::validate(record)
}
