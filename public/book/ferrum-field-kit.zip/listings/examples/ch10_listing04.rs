trait Sink {
    fn send(&mut self, message: &[u8]) -> Result<(), String>;
}

struct MemorySink {
    messages: Vec<Vec<u8>>,
}

impl Sink for MemorySink {
    fn send(&mut self, message: &[u8]) -> Result<(), String> {
        self.messages.push(message.to_vec());
        Ok(())
    }
}

struct LimitedSink {
    remaining: usize,
}

impl Sink for LimitedSink {
    fn send(&mut self, message: &[u8]) -> Result<(), String> {
        if message.len() > self.remaining {
            return Err("capacity exhausted".into());
        }
        self.remaining -= message.len();
        Ok(())
    }
}

struct Router<'a> {
    sinks: Vec<Box<dyn Sink + 'a>>,
}

impl<'a> Router<'a> {
    fn new(sinks: Vec<Box<dyn Sink + 'a>>) -> Self {
        Self { sinks }
    }

    fn broadcast(&mut self, message: &[u8]) -> Vec<String> {
        let mut failures = Vec::new();
        for sink in &mut self.sinks {
            if let Err(error) = sink.send(message) {
                failures.push(error);
            }
        }
        failures
    }
}

fn main() {
    let memory = MemorySink { messages: Vec::new() };
    let limited = LimitedSink { remaining: 3 };
    let mut router = Router::new(vec![
        Box::new(memory),
        Box::new(limited),
    ]);
    assert!(router.broadcast(b"abc").is_empty());
    assert_eq!(router.broadcast(b"x").len(), 1);
}
