fn add_marker(bytes: &mut Vec<u8>) {
    bytes.push(0xff);
}

fn main() {
    let mut bytes = vec![1, 2];
    let access = &mut bytes;
    add_marker(access);
    add_marker(access);
    assert_eq!(access.as_slice(), &[1, 2, 0xff, 0xff]);
}
