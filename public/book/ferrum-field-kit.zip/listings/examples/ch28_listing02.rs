use std::{any::Any, thread::JoinHandle};

#[derive(Debug)]
enum WorkerFailure {
    InvalidInput,
    DependencyUnavailable,
}

#[derive(Default, Debug, PartialEq)]
struct Summary {
    completed: usize,
    domain_failures: usize,
    panics: usize,
}

fn collect(
    workers: Vec<JoinHandle<Result<(), WorkerFailure>>>,
) -> (Summary, Vec<Box<dyn Any + Send>>) {
    let mut summary = Summary::default();
    let mut payloads = Vec::new();
    for worker in workers {
        match worker.join() {
            Ok(Ok(())) => summary.completed += 1,
            Ok(Err(_)) => summary.domain_failures += 1,
            Err(payload) => payloads.push(payload),
        }
    }
    summary.panics = payloads.len();
    (summary, payloads)
}
