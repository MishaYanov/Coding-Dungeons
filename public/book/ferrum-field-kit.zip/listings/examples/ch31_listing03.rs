#![deny(unsafe_op_in_unsafe_fn)]

/// Reads one initialized u32 through a valid shared pointer.
///
/// # Safety
/// pointer must be aligned, live, initialized, and readable for this
/// operation without conflicting access or a data race.
unsafe fn read_word(pointer: *const u32) -> u32 {
    // SAFETY: supplied by this function's caller contract.
    unsafe { pointer.read() }
}

fn main() {
    let word = 123_u32;
    // SAFETY: a live shared reference supplies all read requirements.
    assert_eq!(unsafe { read_word(&word) }, 123);
}
