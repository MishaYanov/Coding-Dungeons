trait Encode<Input> {
    type Error;

    fn encode(&self, value: Input) -> Result<Vec<u8>, Self::Error>;
}

struct Decimal;

impl Encode<u32> for Decimal {
    type Error = std::convert::Infallible;

    fn encode(&self, value: u32) -> Result<Vec<u8>, Self::Error> {
        Ok(value.to_string().into_bytes())
    }
}

impl Encode<bool> for Decimal {
    type Error = std::convert::Infallible;

    fn encode(&self, value: bool) -> Result<Vec<u8>, Self::Error> {
        Ok(if value { b"1" } else { b"0" }.to_vec())
    }
}

fn main() {
    assert_eq!(Decimal.encode(42_u32).unwrap(), b"42");
    assert_eq!(Decimal.encode(true).unwrap(), b"1");
}
