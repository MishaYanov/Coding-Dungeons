struct Trace(&'static str);

impl Drop for Trace {
    fn drop(&mut self) {
        println!("drop {}", self.0);
    }
}

struct Pair {
    first: Trace,
    second: Trace,
}

impl Drop for Pair {
    fn drop(&mut self) {
        println!("drop pair");
    }
}

fn main() {
    let earlier = Trace("earlier local");
    let pair = Pair {
        first: Trace("first field"),
        second: Trace("second field"),
    };
    let later = Trace("later local");
    let _ = (&earlier, &pair.first, &pair.second, &later);
}
