use std::mem::MaybeUninit;

#[repr(C)]
#[derive(Debug, PartialEq)]
struct Statistics {
    accepted: u64,
    rejected: u64,
}

/// # Safety
/// output must be aligned and writable for one Statistics value.
/// On true, it is fully initialized. On false, it is untouched.
unsafe fn fill_statistics(output: *mut Statistics, available: bool) -> bool {
    if !available {
        return false;
    }
    // SAFETY: the caller supplies writable storage, and write does
    // not read or drop its previous uninitialized contents.
    unsafe {
        output.write(Statistics { accepted: 12, rejected: 3 });
    }
    true
}

fn statistics(available: bool) -> Option<Statistics> {
    let mut output = MaybeUninit::<Statistics>::uninit();
    // SAFETY: output supplies aligned writable storage of the exact
    // required type; no initialized value is being overwritten.
    let initialized = unsafe {
        fill_statistics(output.as_mut_ptr(), available)
    };
    if initialized {
        // SAFETY: true is documented to establish every field.
        Some(unsafe { output.assume_init() })
    } else {
        None
    }
}

fn main() {
    assert_eq!(statistics(true), Some(Statistics {
        accepted: 12, rejected: 3,
    }));
    assert_eq!(statistics(false), None);
}
