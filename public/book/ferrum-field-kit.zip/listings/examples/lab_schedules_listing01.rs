#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Event { Check, Register, Admit, Close, Observe }

fn interleavings(left: &[Event], right: &[Event]) -> Vec<Vec<Event>> {
    if left.is_empty() { return vec![right.to_vec()]; }
    if right.is_empty() { return vec![left.to_vec()]; }
    let mut histories = Vec::new();
    for mut tail in interleavings(&left[1..], right) {
        tail.insert(0, left[0]);
        histories.push(tail);
    }
    for mut tail in interleavings(left, &right[1..]) {
        tail.insert(0, right[0]);
        histories.push(tail);
    }
    histories
}

fn safe_at_end(history: &[Event]) -> bool {
    let mut open = true;
    let mut checked_open = false;
    let mut active = 0;
    let mut stopped = false;
    for event in history {
        match event {
            Event::Check => checked_open = open,
            Event::Register => {
                if checked_open { active += 1; }
            }
            Event::Admit => {
                if open { active += 1; }
            }
            Event::Close => open = false,
            Event::Observe => {
                if active == 0 { stopped = true; }
            }
        }
        // No completion event exists in this model, so a late registration
        // remains visible in the final state as well as at this boundary.
        if stopped && active != 0 { return false; }
    }
    true
}

fn main() {
    use Event::*;
    let broken = interleavings(&[Check, Register], &[Close, Observe]);
    assert_eq!(broken.len(), 6);
    let witness = vec![Check, Close, Observe, Register];
    assert!(broken.contains(&witness));
    assert!(!safe_at_end(&witness));
    assert_eq!(broken.iter().filter(|h| !safe_at_end(h)).count(), 1);
    println!("counterexample: {witness:?}");

    let repaired = interleavings(&[Admit], &[Close, Observe]);
    assert_eq!(repaired.len(), 3);
    assert!(repaired.iter().all(|history| safe_at_end(history)));
    println!("repair: all three modeled histories preserve admission");
}
