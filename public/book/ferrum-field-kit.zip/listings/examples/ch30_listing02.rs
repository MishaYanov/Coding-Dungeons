use std::mem::size_of;

fn main() {
    let values = [10_u32, 20, 30];
    let base = values.as_ptr();
    let address = base.addr() + size_of::<u32>();
    let second = base.with_addr(address);
    // SAFETY: second is derived from this live allocation, points
    // to its initialized second element, and only reads shared data.
    assert_eq!(unsafe { second.read() }, 20);
}
