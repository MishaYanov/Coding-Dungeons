use std::cell::Cell;

struct Meter {
    reads: Cell<u64>,
    value: String,
}

impl Meter {
    fn value(&self) -> &str {
        let count = self.reads.get();
        self.reads.set(count.saturating_add(1));
        &self.value
    }

    fn reads(&self) -> u64 {
        self.reads.get()
    }
}

fn main() {
    let meter = Meter {
        reads: Cell::new(0),
        value: String::from("payload"),
    };
    assert_eq!(meter.value(), "payload");
    assert_eq!(meter.value(), "payload");
    assert_eq!(meter.reads(), 2);
}
