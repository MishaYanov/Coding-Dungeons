struct Catalog {
    names: Vec<String>,
}

impl Catalog {
    fn first(&self) -> Option<&str> {
        self.names.first().map(String::as_str)
    }

    fn add(&mut self, name: String) {
        self.names.push(name);
    }
}

fn main() {
    let mut catalog = Catalog {
        names: vec![String::from("alpha")],
    };
    let name = catalog.first().unwrap();
    println!("{name}");
    catalog.add(String::from("beta"));
}
