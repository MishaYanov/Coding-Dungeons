use std::collections::BTreeMap;
use std::sync::Arc;

type Map = BTreeMap<String, String>;

#[derive(Clone)]
struct Snapshot {
    version: u64,
    data: Arc<Map>,
}

struct Store {
    version: u64,
    data: Arc<Map>,
}

struct Transaction {
    base: Snapshot,
    changes: BTreeMap<String, Option<String>>,
}

#[derive(Debug, PartialEq, Eq)]
enum CommitError {
    Conflict,
    VersionExhausted,
}

impl Store {
    fn new() -> Self {
        Self { version: 0, data: Arc::new(Map::new()) }
    }

    fn snapshot(&self) -> Snapshot {
        Snapshot {
            version: self.version,
            data: Arc::clone(&self.data),
        }
    }

    fn begin(&self) -> Transaction {
        Transaction {
            base: self.snapshot(),
            changes: BTreeMap::new(),
        }
    }

    fn commit(&mut self, tx: Transaction)
        -> Result<u64, CommitError>
    {
        if tx.base.version != self.version
            || !Arc::ptr_eq(&tx.base.data, &self.data)
        {
            return Err(CommitError::Conflict);
        }
        if tx.changes.is_empty() {
            return Ok(self.version);
        }
        let next = self.version.checked_add(1)
            .ok_or(CommitError::VersionExhausted)?;
        let mut replacement = (*self.data).clone();
        for (key, value) in tx.changes {
            match value {
                Some(value) => { replacement.insert(key, value); }
                None => { replacement.remove(&key); }
            }
        }
        self.data = Arc::new(replacement);
        self.version = next;
        Ok(next)
    }
}

impl Transaction {
    fn get(&self, key: &str) -> Option<&str> {
        match self.changes.get(key) {
            Some(value) => value.as_deref(),
            None => self.base.data.get(key).map(String::as_str),
        }
    }

    fn put(&mut self, key: String, value: String) {
        self.changes.insert(key, Some(value));
    }

    fn delete(&mut self, key: String) {
        self.changes.insert(key, None);
    }
}

fn main() {
    let mut store = Store::new();
    let other_store = Store::new();
    let foreign = other_store.begin();
    assert_eq!(store.commit(foreign), Err(CommitError::Conflict));
    let before = store.snapshot();
    let mut first = store.begin();
    let mut stale = store.begin();
    first.put("mode".into(), "fast".into());
    assert_eq!(first.get("mode"), Some("fast"));
    assert_eq!(store.commit(first), Ok(1));
    stale.delete("mode".into());
    assert_eq!(store.commit(stale), Err(CommitError::Conflict));
    assert!(before.data.is_empty());
    assert_eq!(store.snapshot().data["mode"], "fast");
}
