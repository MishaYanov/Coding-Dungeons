use std::io::{self, BufRead};

struct LineReader<R> {
    input: R,
    buffer: String,
}

impl<R: BufRead> LineReader<R> {
    fn new(input: R) -> Self {
        Self { input, buffer: String::new() }
    }

    fn next_line(&mut self) -> io::Result<Option<&str>> {
        self.buffer.clear();
        if self.input.read_line(&mut self.buffer)? == 0 {
            return Ok(None);
        }
        let line = self.buffer.as_str();
        let body = line.strip_suffix("\r\n").or_else(|| line.strip_suffix('\n'));
        Ok(Some(body.unwrap_or(line)))
    }
}

fn main() -> io::Result<()> {
    let input = io::Cursor::new(b"alpha\r\nbeta\nend\r");
    let mut reader = LineReader::new(input);
    let mut lengths = Vec::new();
    while let Some(line) = reader.next_line()? {
        lengths.push(line.len());
    }
    assert_eq!(lengths, [5, 4, 4]);
    Ok(())
}
