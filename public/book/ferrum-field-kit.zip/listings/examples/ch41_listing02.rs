#![cfg_attr(not(feature = "std"), no_std)]

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LengthError {
    PayloadTooLarge,
    AddressSpaceOverflow,
}

pub fn encoded_length(payload_len: usize)
    -> Result<usize, LengthError>
{
    if u32::try_from(payload_len).is_err() {
        return Err(LengthError::PayloadTooLarge);
    }
    let length = payload_len.checked_add(4)
        .ok_or(LengthError::AddressSpaceOverflow)?;
    #[cfg(feature = "trace")]
    {
        use std::io::Write;
        let _ = writeln!(std::io::stderr(), "encoded length {length}");
    }
    Ok(length)
}
