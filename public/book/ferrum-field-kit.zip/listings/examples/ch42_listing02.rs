use std::collections::BTreeMap;
use std::sync::{Arc, Mutex};

#[derive(Default)]
struct Cache {
    values: Mutex<BTreeMap<String, Arc<String>>>,
}

impl Cache {
    fn get_or_load<F>(&self, key: &str, load: F) -> Arc<String>
    where
        F: FnOnce() -> String,
    {
        let existing = {
            let guard = self.values.lock().unwrap();
            guard.get(key).cloned()
        };
        if let Some(value) = existing {
            return value;
        }
        let candidate = Arc::new(load());
        let mut guard = self.values.lock().unwrap();
        Arc::clone(guard.entry(key.to_owned()).or_insert(candidate))
    }
}

fn main() {
    let cache = Cache::default();
    let first = cache.get_or_load("mode", || "fast".into());
    let second = cache.get_or_load("mode", || panic!("unused"));
    assert!(Arc::ptr_eq(&first, &second));
    assert_eq!(first.as_str(), "fast");
}
