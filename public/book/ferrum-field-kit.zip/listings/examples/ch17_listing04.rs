macro_rules! commands {
    ($name:ident { $($variant:ident = $code:literal),+ $(,)? }) => {
        #[derive(Debug, Clone, Copy, PartialEq, Eq)]
        #[repr(u8)]
        enum $name {
            $($variant = {
                let code: u128 = $code;
                ::core::assert!(code <= u8::MAX as u128);
                code as u8
            }),+
        }

        impl TryFrom<u8> for $name {
            type Error = u8;

            fn try_from(value: u8) -> Result<Self, Self::Error> {
                match value {
                    $(v if v == Self::$variant as u8 => Ok(Self::$variant),)+
                    unknown => Err(unknown),
                }
            }
        }
    };
}

commands! {
    Command {
        Ping = 1,
        Fetch = 2,
        Close = 9,
    }
}

fn main() {
    assert_eq!(Command::try_from(2), Ok(Command::Fetch));
    assert_eq!(Command::try_from(7), Err(7));
    assert_eq!(Command::Close as u8, 9);
}
