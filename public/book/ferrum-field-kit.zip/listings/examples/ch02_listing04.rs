struct Batch {
    pending: Vec<String>,
    retries: usize,
}

impl Batch {
    fn drain_for_send(&mut self) -> Vec<String> {
        self.retries += 1;
        std::mem::take(&mut self.pending)
    }

    fn restore(&mut self, unsent: Vec<String>) {
        assert!(self.pending.is_empty());
        self.pending = unsent;
    }
}

fn main() {
    let mut batch = Batch {
        pending: vec![String::from("record")],
        retries: 0,
    };
    let outgoing = batch.drain_for_send();
    assert!(batch.pending.is_empty());
    batch.restore(outgoing);
    assert_eq!(batch.pending.len(), 1);
}
