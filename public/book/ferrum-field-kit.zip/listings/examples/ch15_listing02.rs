use std::path::PathBuf;

enum Download {
    Pending { url: String },
    Active { url: String, received: u64 },
    Complete { path: PathBuf, bytes: u64 },
    Failed { url: String, message: String },
}

fn status(download: &Download) -> String {
    match download {
        Download::Pending { url } => format!("waiting for {url}"),
        Download::Active { url, received } => {
            format!("{url} received {received} bytes")
        }
        Download::Complete { path, bytes } => {
            format!("{} contains {bytes} bytes", path.display())
        }
        Download::Failed { url, message } => {
            format!("{url} failed: {message}")
        }
    }
}
