pub struct Counter {
    value: u64,
}

#[unsafe(no_mangle)]
pub extern "C" fn rbook_counter_new() -> *mut Counter {
    Box::into_raw(Box::new(Counter { value: 0 }))
}

/// # Safety
/// If either argument is null, no memory is accessed. Otherwise
/// counter must be a live, exclusive handle from rbook_counter_new
/// and output must be aligned, disjoint u64 storage for exclusive writes.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn rbook_counter_add(
    counter: *mut Counter,
    delta: u64,
    output: *mut u64,
) -> i32 {
    if counter.is_null() || output.is_null() {
        return 1;
    }
    // SAFETY: The caller guarantees a live exclusively accessible handle.
    let counter = unsafe { &mut *counter };
    let Some(next) = counter.value.checked_add(delta) else {
        return 2;
    };
    counter.value = next;
    // SAFETY: output is valid, aligned, writable, and disjoint.
    unsafe { output.write(next) };
    0
}

/// # Safety
/// A nonnull pointer must come from rbook_counter_new and must not have
/// been destroyed. No call or reference may still use the allocation.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn rbook_counter_free(counter: *mut Counter) {
    if !counter.is_null() {
        // SAFETY: This call receives the unique original allocation.
        drop(unsafe { Box::from_raw(counter) });
    }
}
