use std::sync::atomic::{AtomicUsize, Ordering};

fn try_take(available: &AtomicUsize) -> bool {
    let mut current = available.load(Ordering::Relaxed);
    loop {
        if current == 0 {
            return false;
        }
        match available.compare_exchange_weak(
            current,
            current - 1,
            Ordering::Relaxed,
            Ordering::Relaxed,
        ) {
            Ok(_) => return true,
            Err(observed) => current = observed,
        }
    }
}

fn main() {
    let available = AtomicUsize::new(2);
    assert!(try_take(&available));
    assert!(try_take(&available));
    assert!(!try_take(&available));
    assert_eq!(available.load(Ordering::Relaxed), 0);
}
