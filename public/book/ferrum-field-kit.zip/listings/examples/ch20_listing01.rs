use std::collections::VecDeque;
use std::sync::Mutex;

fn take_job(queue: &Mutex<VecDeque<String>>) -> Option<String> {
    let mut jobs = queue.lock().unwrap();
    jobs.pop_front()
}

fn process(job: String) -> usize {
    job.chars().filter(|c| !c.is_whitespace()).count()
}

fn main() {
    let queue = Mutex::new(VecDeque::from([
        String::from("parse one"),
        String::from("parse two"),
    ]));
    let job = take_job(&queue).unwrap();
    assert_eq!(process(job), 8);
    assert_eq!(queue.lock().unwrap().len(), 1);
}
