use std::cell::{Ref, RefCell};

struct Document {
    lines: RefCell<Vec<String>>,
}

impl Document {
    fn first(&self) -> Option<Ref<'_, str>> {
        let lines = self.lines.borrow();
        if lines.is_empty() {
            None
        } else {
            Some(Ref::map(lines, |lines| lines[0].as_str()))
        }
    }

    fn append(&self, line: String) -> Result<(), String> {
        match self.lines.try_borrow_mut() {
            Ok(mut lines) => {
                lines.push(line);
                Ok(())
            }
            Err(_) => Err(line),
        }
    }
}

fn main() {
    let document = Document {
        lines: RefCell::new(vec![String::from("first")]),
    };
    let first = document.first().unwrap();
    assert!(document.append(String::from("second")).is_err());
    assert_eq!(&*first, "first");
    drop(first);
    assert!(document.append(String::from("second")).is_ok());
}
