struct NonEmpty<const N: usize> {
    values: [u8; N],
}

impl<const N: usize> NonEmpty<N> {
    fn new(values: [u8; N]) -> Self {
        const { assert!(N > 0, "capacity must be nonzero"); }
        Self { values }
    }

    fn first(&self) -> u8 { self.values[0] }
}

fn main() {
    let values = NonEmpty::new([7, 8, 9]);
    assert_eq!(values.first(), 7);
}
