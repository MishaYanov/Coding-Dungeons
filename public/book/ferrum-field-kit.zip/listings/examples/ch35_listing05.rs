trait Transform {
    fn apply(&self, value: u64) -> u64;
}

struct Multiply(u64);

impl Transform for Multiply {
    fn apply(&self, value: u64) -> u64 {
        value.wrapping_mul(self.0)
    }
}

fn sum_static<T: Transform>(transform: &T, values: &[u64]) -> u64 {
    values.iter().fold(0_u64, |sum, &value| {
        sum.wrapping_add(transform.apply(value))
    })
}

fn sum_dynamic(transform: &dyn Transform, values: &[u64]) -> u64 {
    values.iter().fold(0_u64, |sum, &value| {
        sum.wrapping_add(transform.apply(value))
    })
}
