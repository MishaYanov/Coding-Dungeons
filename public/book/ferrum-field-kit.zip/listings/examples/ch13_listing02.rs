trait LendingIterator {
    type Item<'a>
    where
        Self: 'a;

    fn next<'a>(&'a mut self) -> Option<Self::Item<'a>>;
}

struct WindowsMut<'data, T> {
    data: &'data mut [T],
    width: usize,
    position: usize,
}

impl<'data, T> WindowsMut<'data, T> {
    fn new(data: &'data mut [T], width: usize) -> Self {
        assert!(width > 0);
        Self { data, width, position: 0 }
    }
}

impl<T> LendingIterator for WindowsMut<'_, T> {
    type Item<'a> = &'a mut [T] where Self: 'a;

    fn next<'a>(&'a mut self) -> Option<Self::Item<'a>> {
        if self.width > self.data.len().saturating_sub(self.position) {
            return None;
        }
        let start = self.position;
        self.position += 1;
        Some(&mut self.data[start..start + self.width])
    }
}

fn main() {
    let mut values = [1, 2, 3, 4];
    {
        let mut windows = WindowsMut::new(&mut values, 2);
        while let Some(window) = windows.next() {
            window[0] += window[1];
        }
    }
    assert_eq!(values, [3, 5, 7, 4]);
}
