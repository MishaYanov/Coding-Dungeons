use std::cell::RefCell;
use std::rc::{Rc, Weak};

struct Node {
    name: String,
    parent: RefCell<Weak<Node>>,
    children: RefCell<Vec<Rc<Node>>>,
}

fn main() {
    let root = Rc::new(Node {
        name: String::from("root"),
        parent: RefCell::new(Weak::new()),
        children: RefCell::new(Vec::new()),
    });
    let child = Rc::new(Node {
        name: String::from("child"),
        parent: RefCell::new(Rc::downgrade(&root)),
        children: RefCell::new(Vec::new()),
    });
    root.children.borrow_mut().push(Rc::clone(&child));
    assert_eq!(child.name, "child");
    assert_eq!(child.parent.borrow().upgrade().unwrap().name, "root");
    drop(root);
    assert!(child.parent.borrow().upgrade().is_none());
}
