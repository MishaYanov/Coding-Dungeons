struct AppendTransaction<'a, T> {
    values: &'a mut Vec<T>,
    original_len: usize,
    committed: bool,
}

impl<'a, T> AppendTransaction<'a, T> {
    fn new(values: &'a mut Vec<T>) -> Self {
        let original_len = values.len();
        Self { values, original_len, committed: false }
    }

    fn push(&mut self, value: T) {
        self.values.push(value);
    }

    fn commit(mut self) {
        self.committed = true;
    }
}

impl<T> Drop for AppendTransaction<'_, T> {
    fn drop(&mut self) {
        if !self.committed {
            self.values.truncate(self.original_len);
        }
    }
}

fn main() {
    let mut values = vec![1, 2];
    {
        let mut transaction = AppendTransaction::new(&mut values);
        transaction.push(3);
    }
    assert_eq!(values, [1, 2]);
    {
        let mut transaction = AppendTransaction::new(&mut values);
        transaction.push(4);
        transaction.commit();
    }
    assert_eq!(values, [1, 2, 4]);
}
