struct Cursor<'input> {
    remaining: &'input str,
}

impl<'input> Cursor<'input> {
    fn new(input: &'input str) -> Self {
        Self { remaining: input }
    }

    fn next_word(&mut self) -> Option<&'input str> {
        self.remaining = self.remaining.trim_start();
        if self.remaining.is_empty() {
            return None;
        }
        let end = self.remaining.find(char::is_whitespace)
            .unwrap_or(self.remaining.len());
        let word = &self.remaining[..end];
        self.remaining = &self.remaining[end..];
        Some(word)
    }
}

fn main() {
    let text = String::from("alpha beta");
    let mut cursor = Cursor::new(&text);
    let first = cursor.next_word().unwrap();
    let second = cursor.next_word().unwrap();
    assert_eq!((first, second), ("alpha", "beta"));
}
