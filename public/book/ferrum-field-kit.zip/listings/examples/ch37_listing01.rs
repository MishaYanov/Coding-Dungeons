#[derive(Debug, PartialEq, Eq)]
struct Record<'a> {
    name: &'a str,
    value: &'a str,
}

#[derive(Debug, PartialEq, Eq)]
enum Kind {
    MissingEquals,
    EmptyName,
    InvalidName,
    EmptyValue,
}

#[derive(Debug, PartialEq, Eq)]
struct ParseError {
    offset: usize,
    kind: Kind,
}

fn parse_line(input: &str) -> Result<Record<'_>, ParseError> {
    let equals = input.find('=').ok_or(ParseError {
        offset: input.len(),
        kind: Kind::MissingEquals,
    })?;
    let left = &input[..equals];
    let right = &input[equals + 1..];
    let name = left.trim();
    let name_start = left.len() - left.trim_start().len();
    if name.is_empty() {
        return Err(ParseError {
            offset: name_start,
            kind: Kind::EmptyName,
        });
    }
    for (index, byte) in name.bytes().enumerate() {
        let valid = byte == b'_'
            || byte.is_ascii_alphabetic()
            || (index > 0 && byte.is_ascii_digit());
        if !valid {
            return Err(ParseError {
                offset: name_start + index,
                kind: Kind::InvalidName,
            });
        }
    }
    let value = right.trim();
    if value.is_empty() {
        return Err(ParseError {
            offset: equals + 1,
            kind: Kind::EmptyValue,
        });
    }
    Ok(Record { name, value })
}

fn main() {
    let input = String::from("  retry_limit = 12  ");
    let record = parse_line(&input).unwrap();
    assert_eq!(record.name, "retry_limit");
    assert_eq!(record.value, "12");
    let bad = parse_line("9retries=12").unwrap_err();
    assert_eq!(bad.offset, 0);
    assert_eq!(bad.kind, Kind::InvalidName);
}
