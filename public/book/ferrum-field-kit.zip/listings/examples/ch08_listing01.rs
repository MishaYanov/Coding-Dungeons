#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct NodeId(usize);

struct Node {
    label: String,
    edges: Vec<NodeId>,
}

#[derive(Default)]
struct Graph {
    nodes: Vec<Node>,
}

impl Graph {
    fn add(&mut self, label: &str) -> NodeId {
        let id = NodeId(self.nodes.len());
        self.nodes.push(Node {
            label: label.to_owned(),
            edges: Vec::new(),
        });
        id
    }

    fn connect(&mut self, from: NodeId, to: NodeId) -> bool {
        if to.0 >= self.nodes.len() {
            return false;
        }
        match self.nodes.get_mut(from.0) {
            Some(node) => {
                node.edges.push(to);
                true
            }
            None => false,
        }
    }

    fn label(&self, id: NodeId) -> Option<&str> {
        self.nodes.get(id.0).map(|node| node.label.as_str())
    }
}

fn main() {
    let mut graph = Graph::default();
    let first = graph.add("first");
    let second = graph.add("second");
    assert!(graph.connect(first, second));
    assert!(graph.connect(second, first));
    assert_eq!(graph.label(first), Some("first"));
}
