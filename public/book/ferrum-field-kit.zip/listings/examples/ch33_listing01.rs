#[repr(C)]
pub struct ByteView {
    pub data: *const u8,
    pub len: usize,
}

/// # Safety
/// For nonzero len, data must identify len initialized readable bytes
/// in one live allocation, with total size at most isize::MAX.
/// The bytes must not be mutated for the duration of this call.
pub unsafe extern "C" fn sum_bytes(view: ByteView) -> u64 {
    if view.len == 0 {
        return 0;
    }
    // SAFETY: The caller supplies the documented readable allocation.
    let bytes = unsafe {
        std::slice::from_raw_parts(view.data, view.len)
    };
    bytes.iter().fold(0_u64, |sum, byte| {
        sum.wrapping_add(u64::from(*byte))
    })
}
