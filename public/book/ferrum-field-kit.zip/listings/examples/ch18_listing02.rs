const fn hex_table() -> [u8; 256] {
    let mut table = [u8::MAX; 256];
    let mut digit = 0;
    while digit < 10 {
        table[b'0' as usize + digit] = digit as u8;
        digit += 1;
    }
    let mut letter = 0;
    while letter < 6 {
        table[b'a' as usize + letter] = (10 + letter) as u8;
        table[b'A' as usize + letter] = (10 + letter) as u8;
        letter += 1;
    }
    table
}

const HEX: [u8; 256] = hex_table();

fn decode_hex(input: &[u8]) -> Option<Vec<u8>> {
    if input.len() % 2 != 0 {
        return None;
    }
    let mut output = Vec::with_capacity(input.len() / 2);
    for pair in input.chunks_exact(2) {
        let high = HEX[pair[0] as usize];
        let low = HEX[pair[1] as usize];
        if high == u8::MAX || low == u8::MAX {
            return None;
        }
        output.push((high << 4) | low);
    }
    Some(output)
}

fn main() {
    assert_eq!(decode_hex(b"0aFF"), Some(vec![10, 255]));
    assert_eq!(decode_hex(b"0x"), None);
    assert_eq!(decode_hex(b"a"), None);
}
