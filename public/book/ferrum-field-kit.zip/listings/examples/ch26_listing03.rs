use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};
use std::thread;

struct CancelOnDrop(Arc<AtomicBool>);

impl Drop for CancelOnDrop {
    fn drop(&mut self) {
        self.0.store(true, Ordering::Release);
    }
}

fn main() {
    let cancelled = Arc::new(AtomicBool::new(false));
    let owner = CancelOnDrop(Arc::clone(&cancelled));
    let worker = thread::spawn(move || {
        let mut batches = 0_u64;
        while !cancelled.load(Ordering::Acquire) {
            batches = batches.wrapping_add(1);
            thread::yield_now();
        }
        batches
    });
    drop(owner);
    let _completed_batches = worker.join().unwrap();
}
