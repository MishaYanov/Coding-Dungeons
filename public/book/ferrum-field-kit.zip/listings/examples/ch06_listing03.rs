fn rebuild<T, E, F>(values: &mut Vec<T>, mut make: F) -> Result<(), E>
where
    F: FnMut(&T) -> Result<T, E>,
{
    let mut next = Vec::with_capacity(values.len());
    for value in values.iter() {
        next.push(make(value)?);
    }
    *values = next;
    Ok(())
}

fn main() {
    let mut values = vec![2, 4, 6];
    let result = rebuild(&mut values, |value| {
        if *value == 4 { Err("rejected") } else { Ok(value * 10) }
    });
    assert_eq!(result, Err("rejected"));
    assert_eq!(values, [2, 4, 6]);
}
