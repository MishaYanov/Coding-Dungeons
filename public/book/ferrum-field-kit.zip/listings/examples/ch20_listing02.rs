use std::sync::Mutex;

#[derive(Debug, PartialEq)]
struct Balance {
    available: u64,
    reserved: u64,
}

struct Account {
    balance: Mutex<Balance>,
}

impl Account {
    fn reserve(&self, amount: u64) -> Result<(), &'static str> {
        let mut state = self.balance.lock().unwrap();
        let available = state.available.checked_sub(amount)
            .ok_or("insufficient balance")?;
        let reserved = state.reserved.checked_add(amount)
            .ok_or("reserved balance overflow")?;
        state.available = available;
        state.reserved = reserved;
        Ok(())
    }

    fn snapshot(&self) -> (u64, u64) {
        let state = self.balance.lock().unwrap();
        (state.available, state.reserved)
    }
}

fn main() {
    let account = Account {
        balance: Mutex::new(Balance {
            available: 100,
            reserved: 0,
        }),
    };
    account.reserve(30).unwrap();
    assert_eq!(account.snapshot(), (70, 30));
    assert!(account.reserve(80).is_err());
    assert_eq!(account.snapshot(), (70, 30));
}
