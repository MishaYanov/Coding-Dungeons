pub struct Snapshot {
    data: std::sync::Arc<[u8]>,
}

fn assert_send_sync<T: Send + Sync>() {}

fn verify_contract() {
    assert_send_sync::<Snapshot>();
}
