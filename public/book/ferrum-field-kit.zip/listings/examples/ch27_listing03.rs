use std::future::Future;

trait Fetch {
    fn fetch(&self) -> impl Future<Output = Vec<u8>> + Send;
}

struct Memory {
    bytes: Vec<u8>,
}

impl Fetch for Memory {
    fn fetch(&self) -> impl Future<Output = Vec<u8>> + Send {
        async move { self.bytes.clone() }
    }
}

fn require_send<T: Send>(_: T) {}

fn main() {
    let source = Memory { bytes: vec![1, 2, 3] };
    require_send(source.fetch());
}
