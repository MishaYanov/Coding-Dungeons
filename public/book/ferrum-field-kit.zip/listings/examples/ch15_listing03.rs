struct Draft;
struct Ready;

struct Request<State> {
    destination: String,
    body: Vec<u8>,
    state: std::marker::PhantomData<State>,
}

#[derive(Debug)]
struct ValidationError;

impl Request<Draft> {
    fn new(destination: String) -> Self {
        Self {
            destination,
            body: Vec::new(),
            state: std::marker::PhantomData,
        }
    }

    fn body(mut self, body: Vec<u8>) -> Self {
        self.body = body;
        self
    }

    fn validate(self) -> Result<Request<Ready>, ValidationError> {
        if self.destination.is_empty() || self.body.len() > 1024 {
            return Err(ValidationError);
        }
        Ok(Request {
            destination: self.destination,
            body: self.body,
            state: std::marker::PhantomData,
        })
    }
}

impl Request<Ready> {
    fn dispatch(self) -> (String, Vec<u8>) {
        (self.destination, self.body)
    }
}

fn main() {
    let request = Request::new("worker-7".into())
        .body(b"rebuild".to_vec())
        .validate()
        .unwrap();
    let (destination, body) = request.dispatch();
    assert_eq!(destination, "worker-7");
    assert_eq!(body, b"rebuild");
}
