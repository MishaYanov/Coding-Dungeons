#[derive(Debug, PartialEq, Eq)]
struct WrongLength {
    expected: usize,
    actual: usize,
}

struct Packet<const N: usize> {
    bytes: [u8; N],
}

impl<const N: usize> Packet<N> {
    fn from_slice(input: &[u8]) -> Result<Self, WrongLength> {
        let bytes: [u8; N] = input.try_into().map_err(|_| WrongLength {
            expected: N,
            actual: input.len(),
        })?;
        Ok(Self { bytes })
    }

    fn as_slice(&self) -> &[u8] { &self.bytes }

    fn checksum(&self) -> u8 {
        self.bytes.iter().fold(0, |sum, byte| sum.wrapping_add(*byte))
    }
}

fn main() {
    let packet = Packet::<4>::from_slice(&[1, 2, 3, 4]).unwrap();
    assert_eq!(packet.checksum(), 10);
    assert_eq!(packet.as_slice().len(), 4);
    assert!(Packet::<4>::from_slice(&[1, 2]).is_err());
}
