fn main() {
    let text = String::from("aé");
    assert_eq!(text.len(), 3);
    assert_eq!(text.chars().count(), 2);
    assert_eq!(text.get(0..1), Some("a"));
    assert_eq!(text.get(1..3), Some("é"));
    assert_eq!(text.get(0..2), None);
}
