use std::panic::{catch_unwind, AssertUnwindSafe};

fn main() {
    let mut values = vec![1];
    let result = catch_unwind(AssertUnwindSafe(|| {
        values.push(2);
        panic!("interrupted after mutation");
    }));
    assert!(result.is_err());
    assert_eq!(values, [1, 2]);
}
