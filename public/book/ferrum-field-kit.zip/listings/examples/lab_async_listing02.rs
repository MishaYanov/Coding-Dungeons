use std::future::Future;
use std::pin::Pin;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::mpsc::{sync_channel, Receiver, SyncSender};
use std::sync::{Arc, Condvar, Mutex};
use std::task::{Context, Poll, Wake, Waker};
use std::thread::{self, JoinHandle};

#[derive(Debug, PartialEq)]
enum Outcome { Completed(u32), Cancelled, Expired, Overflow }
#[derive(Debug)]
enum Rejected { Closed(u32), Busy(u32), WorkerGone(u32) }
impl Rejected {
    fn into_value(self) -> u32 {
        match self {
            Self::Closed(value) | Self::Busy(value)
                | Self::WorkerGone(value) => value,
        }
    }
}
struct Gate { open: bool, active: usize }
struct Permit(Arc<Mutex<Gate>>);
impl Drop for Permit {
    fn drop(&mut self) { self.0.lock().unwrap().active -= 1; }
}
struct Reply { result: Option<Outcome>, waiter: Option<Waker> }
struct Operation(Arc<Mutex<Reply>>);
impl Future for Operation {
    type Output = Outcome;
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>)
        -> Poll<Outcome>
    {
        let next = cx.waker().clone();
        let mut reply = self.0.lock().unwrap();
        if let Some(result) = reply.result.take() {
            return Poll::Ready(result);
        }
        let old = reply.waiter.replace(next);
        drop(reply);
        drop(old);
        Poll::Pending
    }
}
struct Control {
    release: Option<SyncSender<()>>,
    recorded: Receiver<()>,
    cancel: Arc<AtomicBool>,
    now: Arc<AtomicU64>,
}
impl Control {
    fn resume_and_observe(&mut self) {
        self.release.take().unwrap().send(()).unwrap();
        self.recorded.recv().unwrap();
    }
}
struct Job {
    value: u32, deadline: u64,
    permit: Permit, reply: Arc<Mutex<Reply>>,
    release: Receiver<()>, recorded: SyncSender<()>,
    cancel: Arc<AtomicBool>, now: Arc<AtomicU64>,
}
struct Service {
    gate: Arc<Mutex<Gate>>,
    input: SyncSender<Job>, worker: JoinHandle<()>,
}
impl Service {
    fn new() -> Self {
        let gate = Arc::new(Mutex::new(Gate { open: true, active: 0 }));
        let (input, jobs) = sync_channel::<Job>(1);
        let worker = thread::spawn(move || {
            while let Ok(job) = jobs.recv() {
                let outcome = if job.release.recv().is_err()
                    || job.cancel.load(Ordering::Relaxed) {
                    Outcome::Cancelled
                } else if job.now.load(Ordering::Relaxed) >= job.deadline {
                    Outcome::Expired
                } else {
                    job.value.checked_mul(2)
                        .map(Outcome::Completed).unwrap_or(Outcome::Overflow)
                };
                let waiter = {
                    let mut reply = job.reply.lock().unwrap();
                    reply.result = Some(outcome);
                    reply.waiter.take()
                };
                drop(job.permit);
                if let Some(waiter) = waiter { waiter.wake(); }
                let _ = job.recorded.send(());
            }
        });
        Self { gate, input, worker }
    }
    fn submit(&self, value: u32, deadline: u64)
        -> Result<(Operation, Control), Rejected>
    {
        {
            let mut gate = self.gate.lock().unwrap();
            if !gate.open { return Err(Rejected::Closed(value)); }
            if gate.active == 1 { return Err(Rejected::Busy(value)); }
            gate.active += 1;
        }
        let permit = Permit(Arc::clone(&self.gate));
        let reply = Arc::new(Mutex::new(Reply { result: None, waiter: None }));
        let (release, checkpoint) = sync_channel(1);
        let (recorded, observed) = sync_channel(1);
        let cancel = Arc::new(AtomicBool::new(false));
        let now = Arc::new(AtomicU64::new(0));
        let job = Job { value, deadline, permit, reply: Arc::clone(&reply),
            release: checkpoint, recorded, cancel: Arc::clone(&cancel),
            now: Arc::clone(&now) };
        self.input.try_send(job).map_err(|_| Rejected::WorkerGone(value))?;
        Ok((Operation(reply), Control { release: Some(release),
            recorded: observed, cancel, now }))
    }
    fn close(&self) { self.gate.lock().unwrap().open = false; }
    fn shutdown(self) -> usize {
        self.close();
        drop(self.input);
        self.worker.join().unwrap();
        self.gate.lock().unwrap().active
    }
}
struct Signal { ready: Mutex<bool>, changed: Condvar }
impl Wake for Signal {
    fn wake(self: Arc<Self>) { self.wake_by_ref(); }
    fn wake_by_ref(self: &Arc<Self>) {
        *self.ready.lock().unwrap() = true;
        self.changed.notify_one();
    }
}
fn drive<F: Future>(future: F, mut after_pending: impl FnMut())
    -> (F::Output, usize)
{
    let signal = Arc::new(Signal {
        ready: Mutex::new(false), changed: Condvar::new() });
    let waker = Waker::from(Arc::clone(&signal));
    let mut context = Context::from_waker(&waker);
    let mut future = Box::pin(future);
    let mut polls = 0;
    loop {
        polls += 1;
        if let Poll::Ready(result) = future.as_mut().poll(&mut context) {
            return (result, polls);
        }
        after_pending();
        let mut ready = signal.ready.lock().unwrap();
        while !*ready { ready = signal.changed.wait(ready).unwrap(); }
        *ready = false;
    }
}
fn scenario(value: u32, now: u64, cancel: bool, expected: Outcome) {
    let service = Service::new();
    let (operation, mut control) = service.submit(value, 10).unwrap();
    let busy = service.submit(9, 10).err().expect("must reject");
    assert!(matches!(&busy, Rejected::Busy(_)));
    assert_eq!(busy.into_value(), 9);
    service.close();
    let closed = service.submit(8, 10).err().expect("must reject");
    assert!(matches!(&closed, Rejected::Closed(_)));
    assert_eq!(closed.into_value(), 8);
    let (result, polls) = drive(operation, || {
        control.now.store(now, Ordering::Relaxed);
        control.cancel.store(cancel, Ordering::Relaxed);
        control.resume_and_observe();
    });
    assert_eq!((result, polls), (expected, 2));
    assert_eq!(service.shutdown(), 0);
}
fn main() {
    scenario(21, 1, false, Outcome::Completed(42));
    scenario(21, 1, true, Outcome::Cancelled);
    scenario(21, 10, false, Outcome::Expired);
    scenario(u32::MAX, 1, false, Outcome::Overflow);
    let service = Service::new();
    let (operation, control) = service.submit(21, 10).unwrap();
    drop(control);
    assert_eq!(drive(operation, || {}).0, Outcome::Cancelled);
    assert_eq!(service.shutdown(), 0);
    let service = Service::new();
    let (operation, mut control) = service.submit(21, 10).unwrap();
    drop(operation);
    let busy = service.submit(7, 10).err().expect("must reject");
    assert!(matches!(&busy, Rejected::Busy(_)));
    assert_eq!(busy.into_value(), 7);
    control.resume_and_observe();
    assert_eq!(service.shutdown(), 0);
}
