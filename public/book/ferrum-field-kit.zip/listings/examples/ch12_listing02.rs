fn main() {
    let prefix = String::from("job");
    let format_name = move |id: u64| format!("{prefix}-{id}");

    assert_eq!(format_name(3), "job-3");
    assert_eq!(format_name(4), "job-4");
}
