trait Text {
    fn describe(&self) -> &'static str;
}

trait Wire {
    fn describe(&self) -> &'static str;
}

struct Packet;

impl Text for Packet {
    fn describe(&self) -> &'static str { "human readable" }
}

impl Wire for Packet {
    fn describe(&self) -> &'static str { "binary frame" }
}

fn main() {
    let packet = Packet;
    assert_eq!(<Packet as Wire>::describe(&packet), "binary frame");
    assert_eq!(Text::describe(&packet), "human readable");
}
