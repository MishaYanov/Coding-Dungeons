struct Row {
    score: u64,
    payload: [u8; 128],
}

struct Columns {
    scores: Vec<u64>,
    payloads: Vec<[u8; 128]>,
}

fn sum_rows(rows: &[Row]) -> u64 {
    rows.iter().fold(0, |sum, row| sum.wrapping_add(row.score))
}

fn sum_columns(columns: &Columns) -> u64 {
    columns.scores.iter().copied().fold(0, u64::wrapping_add)
}

fn split_rows(rows: Vec<Row>) -> Columns {
    let mut scores = Vec::with_capacity(rows.len());
    let mut payloads = Vec::with_capacity(rows.len());
    for row in rows {
        scores.push(row.score);
        payloads.push(row.payload);
    }
    Columns { scores, payloads }
}
