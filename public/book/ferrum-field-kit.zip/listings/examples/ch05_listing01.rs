fn shorten<'a>(text: &'static str) -> &'a str {
    text
}

fn main() {
    let local = String::from("local");
    let always = shorten("always available");
    let pair = [local.as_str(), always];
    assert_eq!(pair[1], "always available");
}
