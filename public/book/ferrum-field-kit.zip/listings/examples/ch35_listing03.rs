use std::fmt::Write;

struct Record<'a> {
    id: u64,
    name: &'a str,
}

fn render(records: &[Record<'_>], output: &mut String) {
    output.clear();
    for record in records {
        writeln!(output, "{}\t{}", record.id, record.name)
            .expect("writing to String cannot fail");
    }
}

fn main() {
    let records = [
        Record { id: 1, name: "alpha" },
        Record { id: 2, name: "beta" },
    ];
    let mut output = String::new();
    render(&records, &mut output);
    assert_eq!(output, "1\talpha\n2\tbeta\n");
    let capacity = output.capacity();
    render(&records, &mut output);
    assert_eq!(output.capacity(), capacity);
}
