use std::sync::{Arc, Mutex};

#[derive(Clone, Copy, Debug, PartialEq)]
enum Phase {
    Accepting,
    Draining,
    Stopped,
}

struct State {
    phase: Phase,
    active: usize,
    limit: usize,
}

#[derive(Clone)]
struct Admission(Arc<Mutex<State>>);

struct Lease(Arc<Mutex<State>>);

impl Admission {
    fn new(limit: usize) -> Self {
        Self(Arc::new(Mutex::new(State {
            phase: Phase::Accepting,
            active: 0,
            limit,
        })))
    }

    fn try_enter(&self) -> Option<Lease> {
        let mut state = self.0.lock().unwrap();
        if state.phase != Phase::Accepting || state.active == state.limit {
            return None;
        }
        state.active += 1;
        Some(Lease(Arc::clone(&self.0)))
    }

    fn close(&self) {
        let mut state = self.0.lock().unwrap();
        state.phase = if state.active == 0 {
            Phase::Stopped
        } else {
            Phase::Draining
        };
    }

    fn snapshot(&self) -> (Phase, usize) {
        let state = self.0.lock().unwrap();
        (state.phase, state.active)
    }
}

impl Drop for Lease {
    fn drop(&mut self) {
        let mut state = self.0.lock().unwrap();
        state.active -= 1;
        if state.phase == Phase::Draining && state.active == 0 {
            state.phase = Phase::Stopped;
        }
    }
}

fn main() {
    let admission = Admission::new(2);
    let first = admission.try_enter().unwrap();
    let second = admission.try_enter().unwrap();
    assert!(admission.try_enter().is_none());
    admission.close();
    assert_eq!(admission.snapshot(), (Phase::Draining, 2));
    assert!(admission.try_enter().is_none());
    drop(first);
    drop(second);
    assert_eq!(admission.snapshot(), (Phase::Stopped, 0));
}
