use std::sync::{Arc, Mutex};
use std::thread;

fn main() {
    let cache = Arc::new(Mutex::new(vec![1_u32, 2, 3]));
    let other = Arc::clone(&cache);
    let result = thread::spawn(move || {
        let mut values = other.lock().unwrap();
        values.push(99);
        panic!("cache rebuild interrupted");
    }).join();
    assert!(result.is_err());

    let mut values = match cache.lock() {
        Ok(guard) => guard,
        Err(poisoned) => {
            let mut guard = poisoned.into_inner();
            guard.clear();
            cache.clear_poison();
            guard
        }
    };
    values.push(7);
    assert_eq!(&*values, &[7]);
}
