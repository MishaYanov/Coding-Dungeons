use std::fmt::Display;

struct Slot<T> {
    value: Option<T>,
}

impl<T> Slot<T> {
    fn empty() -> Self { Self { value: None } }

    fn insert(&mut self, value: T) -> Option<T> {
        self.value.replace(value)
    }

    fn take(&mut self) -> Option<T> {
        self.value.take()
    }
}

impl<T: Display> Slot<T> {
    fn describe(&self) -> String {
        match &self.value {
            Some(value) => value.to_string(),
            None => "empty".into(),
        }
    }
}

fn main() {
    let mut slot = Slot::empty();
    slot.insert(42);
    assert_eq!(slot.describe(), "42");
    assert_eq!(slot.take(), Some(42));
}
