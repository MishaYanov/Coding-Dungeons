struct Draft {
    bytes: Vec<u8>,
}

struct Ready {
    bytes: Vec<u8>,
    checksum: u64,
}

impl Draft {
    fn new() -> Self {
        Self { bytes: Vec::new() }
    }

    fn append(&mut self, bytes: &[u8]) {
        self.bytes.extend_from_slice(bytes);
    }

    fn finish(self) -> Ready {
        let checksum = self.bytes.iter()
            .fold(0_u64, |sum, byte| sum + u64::from(*byte));
        Ready { bytes: self.bytes, checksum }
    }
}

impl Ready {
    fn submit(self) -> (usize, u64) {
        (self.bytes.len(), self.checksum)
    }
}

fn main() {
    let mut draft = Draft::new();
    draft.append(b"request");
    let ready = draft.finish();
    assert_eq!(ready.submit(), (7, 777));
}
