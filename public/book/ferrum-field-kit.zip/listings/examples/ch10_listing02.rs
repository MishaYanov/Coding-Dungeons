trait Metric {
    fn observe(&mut self, value: u64);
    fn current(&self) -> u64;
}

struct Maximum(u64);

impl Metric for Maximum {
    fn observe(&mut self, value: u64) {
        self.0 = self.0.max(value);
    }

    fn current(&self) -> u64 { self.0 }
}

fn record(metric: &mut dyn Metric, values: &[u64]) {
    for &value in values {
        metric.observe(value);
    }
}

fn main() {
    let mut maximum = Maximum(0);
    record(&mut maximum, &[3, 5, 8]);
    let view: &dyn Metric = &maximum;
    assert_eq!(view.current(), 8);
}
