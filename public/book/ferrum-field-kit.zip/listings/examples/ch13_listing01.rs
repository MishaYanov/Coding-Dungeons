struct EveryOther<'data, T> {
    remaining: &'data [T],
}

impl<'data, T> Iterator for EveryOther<'data, T> {
    type Item = &'data T;

    fn next(&mut self) -> Option<Self::Item> {
        let (first, rest) = self.remaining.split_first()?;
        self.remaining = if rest.is_empty() { rest } else { &rest[1..] };
        Some(first)
    }
}

fn main() {
    let values = [10, 20, 30, 40];
    let mut iter = EveryOther { remaining: &values };
    let first = iter.next().unwrap();
    let second = iter.next().unwrap();
    assert_eq!((*first, *second), (10, 30));
}
