use std::error::Error;
use std::fmt;
use std::io;
use std::path::{Path, PathBuf};

#[derive(Debug)]
enum LoadError {
    Read { path: PathBuf, source: io::Error },
    InvalidLimit { line: usize, value: String },
}

impl fmt::Display for LoadError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Read { path, .. } => {
                write!(f, "cannot read configuration {}", path.display())
            }
            Self::InvalidLimit { line, value } => {
                write!(f, "invalid limit on line {line}: {value:?}")
            }
        }
    }
}

impl Error for LoadError {
    fn source(&self) -> Option<&(dyn Error + 'static)> {
        match self {
            Self::Read { source, .. } => Some(source),
            Self::InvalidLimit { .. } => None,
        }
    }
}

fn load_limit(path: &Path) -> Result<u32, LoadError> {
    let text = std::fs::read_to_string(path).map_err(|source| {
        LoadError::Read { path: path.to_owned(), source }
    })?;
    let value = text.lines().next().unwrap_or("").trim();
    value.parse().map_err(|_| LoadError::InvalidLimit {
        line: 1,
        value: value.to_owned(),
    })
}
