#[derive(Debug, PartialEq, Eq)]
enum Request {
    Queued { id: u64, body: Vec<u8> },
    Running { id: u64, body: Vec<u8> },
    Done { id: u64, status: u16 },
}

impl Request {
    fn start(self) -> Result<Self, Self> {
        match self {
            Self::Queued { id, body } => {
                Ok(Self::Running { id, body })
            }
            other => Err(other),
        }
    }

    fn finish(self, status: u16) -> Result<Self, Self> {
        match self {
            Self::Running { id, .. } => {
                Ok(Self::Done { id, status })
            }
            other => Err(other),
        }
    }
}

fn main() {
    let request = Request::Queued { id: 7, body: vec![1, 2] };
    let running = request.start().unwrap();
    let done = running.finish(200).unwrap();
    assert_eq!(done, Request::Done { id: 7, status: 200 });
    assert!(done.start().is_err());
}
