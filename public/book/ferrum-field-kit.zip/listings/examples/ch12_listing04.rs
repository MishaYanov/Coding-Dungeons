struct Predicate<'a> {
    test: Box<dyn Fn(&str) -> bool + 'a>,
}

impl<'a> Predicate<'a> {
    fn new<F>(test: F) -> Self
    where
        F: Fn(&str) -> bool + 'a,
    {
        Self { test: Box::new(test) }
    }

    fn accepts(&self, value: &str) -> bool {
        (self.test)(value)
    }
}

fn main() {
    let prefix = String::from("build/");
    let predicate = Predicate::new(|value| value.starts_with(&prefix));
    assert!(predicate.accepts("build/linux"));
    assert!(!predicate.accepts("test/linux"));
}
