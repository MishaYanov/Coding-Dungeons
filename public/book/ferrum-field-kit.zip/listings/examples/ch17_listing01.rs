macro_rules! pairs {
    ($($key:expr => $value:expr),* $(,)?) => {{
        let mut result = Vec::new();
        $(result.push(($key, $value));)*
        result
    }};
}

fn main() {
    let mut next = 0;
    let values = pairs! {
        "first" => { next += 1; next },
        "second" => { next += 1; next },
    };
    assert_eq!(values, [("first", 1), ("second", 2)]);
    assert_eq!(next, 2);
}
