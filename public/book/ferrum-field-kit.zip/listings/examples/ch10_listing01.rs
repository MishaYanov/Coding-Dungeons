trait Metric {
    fn observe(&mut self, value: u64);
}

#[derive(Default)]
struct Total(u64);

impl Metric for Total {
    fn observe(&mut self, value: u64) {
        self.0 += value;
    }
}

fn record<M: Metric>(metric: &mut M, values: &[u64]) {
    for &value in values {
        metric.observe(value);
    }
}

fn main() {
    let mut metric = Total::default();
    record(&mut metric, &[3, 5, 8]);
    assert_eq!(metric.0, 16);
}
