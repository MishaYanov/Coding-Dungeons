use std::cell::Cell;
use std::marker::PhantomPinned;
use std::pin::Pin;

struct Resident {
    address: Cell<Option<usize>>,
    _pinned: PhantomPinned,
}

impl Resident {
    fn observe(self: Pin<&Self>) -> usize {
        let current = self.get_ref() as *const Self as usize;
        if let Some(previous) = self.address.get() {
            assert_eq!(previous, current);
        } else {
            self.address.set(Some(current));
        }
        current
    }
}

fn main() {
    let resident = Box::pin(Resident {
        address: Cell::new(None),
        _pinned: PhantomPinned,
    });
    let before = resident.as_ref().observe();
    let mut owners = Vec::new();
    owners.push(resident);
    for _ in 0..100 {
        owners.reserve(1);
    }
    let resident = owners.pop().unwrap();
    assert_eq!(resident.as_ref().observe(), before);
}
