use std::collections::BTreeMap;
use std::sync::Arc;

fn main() {
    let mut current = Arc::new(BTreeMap::from([
        (String::from("limit"), 10_u32),
    ]));
    let old = Arc::clone(&current);
    Arc::make_mut(&mut current).insert("limit".into(), 20);
    assert_eq!(old["limit"], 10);
    assert_eq!(current["limit"], 20);
    assert!(!Arc::ptr_eq(&old, &current));
}
