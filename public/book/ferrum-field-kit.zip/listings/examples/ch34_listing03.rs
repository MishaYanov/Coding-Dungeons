use std::collections::HashMap;

fn add_count(counts: &mut HashMap<String, u64>, name: &str) {
    if let Some(count) = counts.get_mut(name) {
        *count += 1;
    } else {
        counts.insert(name.to_owned(), 1);
    }
}

fn main() {
    let mut counts = HashMap::new();
    add_count(&mut counts, "compile");
    add_count(&mut counts, "compile");
    assert_eq!(counts.get("compile"), Some(&2));
}
