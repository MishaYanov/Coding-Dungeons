fn choose_name(use_cache: bool) -> String {
    let name;
    if use_cache {
        name = String::from("cached");
    } else {
        name = String::from("fresh");
    }
    name
}

fn main() {
    assert_eq!(choose_name(true), "cached");
    assert_eq!(choose_name(false), "fresh");
}
