use std::cell::Cell;

fn main() {
    let pending = Cell::new(Some(String::from("work")));
    let work = pending.take().unwrap();
    assert!(pending.take().is_none());
    pending.set(Some(work.to_uppercase()));
    assert_eq!(pending.take().as_deref(), Some("WORK"));
}
