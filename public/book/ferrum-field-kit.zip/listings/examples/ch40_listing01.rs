#[derive(Debug, PartialEq, Eq)]
enum Frame {
    Offer(u16),
    Data { sequence: u32, payload: Vec<u8> },
    Close,
}

#[derive(Debug)]
struct Negotiating {
    offers: usize,
}

#[derive(Debug)]
struct Established {
    next_sequence: u32,
}

#[derive(Debug)]
struct Closed;

#[derive(Debug)]
struct Connection<S> {
    transcript: Vec<Frame>,
    state: S,
}

#[derive(Debug, PartialEq, Eq)]
enum SendError {
    PayloadTooLarge,
    SequenceExhausted,
}

impl Connection<Negotiating> {
    fn new() -> Self {
        Self {
            transcript: Vec::new(),
            state: Negotiating { offers: 0 },
        }
    }

    fn negotiate(mut self, version: u16)
        -> Result<Connection<Established>, Self>
    {
        self.state.offers += 1;
        self.transcript.push(Frame::Offer(version));
        if version != 1 {
            return Err(self);
        }
        Ok(Connection {
            transcript: self.transcript,
            state: Established { next_sequence: 0 },
        })
    }
}

impl Connection<Established> {
    fn send(&mut self, payload: Vec<u8>)
        -> Result<u32, (SendError, Vec<u8>)>
    {
        if payload.len() > 1024 {
            return Err((SendError::PayloadTooLarge, payload));
        }
        let sequence = self.state.next_sequence;
        let Some(next) = sequence.checked_add(1) else {
            return Err((SendError::SequenceExhausted, payload));
        };
        self.transcript.push(Frame::Data { sequence, payload });
        self.state.next_sequence = next;
        Ok(sequence)
    }

    fn close(mut self) -> Connection<Closed> {
        self.transcript.push(Frame::Close);
        Connection { transcript: self.transcript, state: Closed }
    }
}

impl Connection<Closed> {
    fn transcript(&self) -> &[Frame] {
        &self.transcript
    }
}

fn main() {
    let negotiating = Connection::new();
    let negotiating = negotiating.negotiate(2).unwrap_err();
    let mut ready = negotiating.negotiate(1).unwrap();
    assert_eq!(ready.send(vec![10, 20]), Ok(0));
    let closed = ready.close();
    assert_eq!(closed.transcript().len(), 4);
    assert_eq!(closed.transcript().last(), Some(&Frame::Close));
}
