pub struct RetryPolicy {
    attempts: u32,
    base_delay_ms: u64,
}

#[derive(Debug, PartialEq, Eq)]
pub enum PolicyError {
    ZeroAttempts,
}

impl RetryPolicy {
    pub fn new(attempts: u32) -> Result<Self, PolicyError> {
        if attempts == 0 {
            return Err(PolicyError::ZeroAttempts);
        }
        Ok(Self { attempts, base_delay_ms: 100 })
    }

    pub fn with_base_delay_ms(mut self, delay: u64) -> Self {
        self.base_delay_ms = delay;
        self
    }

    pub fn attempts(&self) -> u32 { self.attempts }

    pub fn delay_for(&self, retry: u32) -> u64 {
        self.base_delay_ms.saturating_mul(u64::from(retry))
    }
}
