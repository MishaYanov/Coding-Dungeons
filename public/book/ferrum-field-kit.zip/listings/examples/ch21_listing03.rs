use std::sync::mpsc::{self, Sender};
use std::thread;

enum Command {
    Add {
        amount: u64,
        reply: Sender<Result<u64, &'static str>>,
    },
    Read(Sender<u64>),
}

fn run(receiver: mpsc::Receiver<Command>) -> u64 {
    let mut value = 0_u64;
    for command in receiver {
        match command {
            Command::Add { amount, reply } => {
                let result = match value.checked_add(amount) {
                    Some(next) => {
                        value = next;
                        Ok(next)
                    }
                    None => Err("counter overflow"),
                };
                let _ = reply.send(result);
            }
            Command::Read(reply) => {
                let _ = reply.send(value);
            }
        }
    }
    value
}

fn main() {
    let (sender, receiver) = mpsc::channel();
    let owner = thread::spawn(move || run(receiver));

    let (reply, response) = mpsc::channel();
    sender.send(Command::Add { amount: 7, reply }).unwrap();
    assert_eq!(response.recv().unwrap(), Ok(7));

    let (reply, response) = mpsc::channel();
    sender.send(Command::Read(reply)).unwrap();
    assert_eq!(response.recv().unwrap(), 7);
    drop(sender);
    assert_eq!(owner.join().unwrap(), 7);
}
