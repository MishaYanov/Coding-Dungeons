#[derive(Debug, PartialEq, Eq)]
enum TransferError {
    InvalidAccount,
    SameAccount,
    InsufficientFunds,
    DestinationOverflow,
}

fn transfer(balances: &mut [u64], from: usize,
            to: usize, amount: u64)
    -> Result<(), TransferError>
{
    if from == to {
        return Err(TransferError::SameAccount);
    }
    let source = *balances.get(from)
        .ok_or(TransferError::InvalidAccount)?;
    let destination = *balances.get(to)
        .ok_or(TransferError::InvalidAccount)?;
    let new_source = source.checked_sub(amount)
        .ok_or(TransferError::InsufficientFunds)?;
    let new_destination = destination.checked_add(amount)
        .ok_or(TransferError::DestinationOverflow)?;
    balances[from] = new_source;
    balances[to] = new_destination;
    Ok(())
}

fn main() {
    let mut balances = [50, 10];
    transfer(&mut balances, 0, 1, 20).unwrap();
    assert_eq!(balances, [30, 30]);
    let before = balances;
    assert_eq!(transfer(&mut balances, 0, 1, 100),
        Err(TransferError::InsufficientFunds));
    assert_eq!(balances, before);
    let mut overflow = [1, u64::MAX];
    assert_eq!(transfer(&mut overflow, 0, 1, 1),
        Err(TransferError::DestinationOverflow));
    assert_eq!(overflow, [1, u64::MAX]);
}
