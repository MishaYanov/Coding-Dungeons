use std::collections::HashMap;
use std::future::{self, Future, Ready};

trait Store {
    type Read<'a>: Future<Output = Option<&'a str>> + 'a
    where
        Self: 'a;

    fn read<'a>(&'a self, key: &'a str) -> Self::Read<'a>;
}

struct MemoryStore {
    entries: HashMap<String, String>,
}

impl Store for MemoryStore {
    type Read<'a> = Ready<Option<&'a str>>;

    fn read<'a>(&'a self, key: &'a str) -> Self::Read<'a> {
        future::ready(self.entries.get(key).map(String::as_str))
    }
}
