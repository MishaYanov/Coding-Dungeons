use std::any::Any;
use std::ffi::c_void;
use std::panic::{self, AssertUnwindSafe};

struct Context<F> {
    callback: F,
    panic: Option<Box<dyn Any + Send>>,
}

/// # Safety
/// The context must be a live Context<F> on visit's thread.
/// Each call must have exclusive access through its return.
unsafe extern "C" fn trampoline<F: FnMut(i32)>(
    context: *mut c_void,
    value: i32,
) {
    // SAFETY: The caller guarantees validity and exclusive access.
    let context = unsafe { &mut *context.cast::<Context<F>>() };
    if context.panic.is_some() {
        return;
    }
    let result = panic::catch_unwind(AssertUnwindSafe(|| {
        (context.callback)(value);
    }));
    if let Err(payload) = result {
        context.panic = Some(payload);
    }
}

fn visit<F: FnMut(i32)>(values: &[i32], callback: F) {
    let mut context = Context { callback, panic: None };
    let raw = (&mut context as *mut Context<F>).cast::<c_void>();
    for &value in values {
        // SAFETY: Same thread, serial calls, and the exact context type.
        unsafe { trampoline::<F>(raw, value) };
    }
    if let Some(payload) = context.panic {
        panic::resume_unwind(payload);
    }
}

fn main() {
    let mut total = 0;
    visit(&[2, 3, 5], |value| total += value);
    assert_eq!(total, 10);
}
