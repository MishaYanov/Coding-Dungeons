use std::mem::MaybeUninit;

struct Pair {
    left: u32,
    right: u32,
}

fn main() {
    let mut storage = MaybeUninit::<Pair>::uninit();
    let pointer = storage.as_mut_ptr();
    // SAFETY: these raw field addresses are within allocated storage;
    // write initializes each field without reading an old value.
    unsafe {
        (&raw mut (*pointer).left).write(10);
        (&raw mut (*pointer).right).write(20);
    }
    // SAFETY: both fields now contain valid initialized u32 values.
    let pair = unsafe { storage.assume_init() };
    assert_eq!(pair.left + pair.right, 30);
}
