struct CommitQueue<'a> {
    actions: Vec<Box<dyn FnOnce() + 'a>>,
}

impl<'a> CommitQueue<'a> {
    fn new() -> Self { Self { actions: Vec::new() } }

    fn push<F>(&mut self, action: F)
    where
        F: FnOnce() + 'a,
    {
        self.actions.push(Box::new(action));
    }

    fn run(self) {
        for action in self.actions {
            action();
        }
    }
}

fn main() {
    let mut output = Vec::new();
    {
        let mut queue = CommitQueue::new();
        let message = String::from("committed");
        queue.push(|| output.push(message));
        queue.run();
    }
    assert_eq!(output, [String::from("committed")]);
}
