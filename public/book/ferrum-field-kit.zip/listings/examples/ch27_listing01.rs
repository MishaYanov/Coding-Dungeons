trait Lookup {
    async fn find(&self, key: &str) -> Option<String>;
}

struct PrefixLookup {
    prefix: String,
}

impl Lookup for PrefixLookup {
    async fn find(&self, key: &str) -> Option<String> {
        key.strip_prefix(&self.prefix).map(str::to_owned)
    }
}

async fn query<L: Lookup>(lookup: &L) -> Option<String> {
    lookup.find("item:42").await
}
