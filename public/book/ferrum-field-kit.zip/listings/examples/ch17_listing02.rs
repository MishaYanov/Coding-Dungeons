macro_rules! inspect_value {
    ($expression:expr) => {{
        let value = $expression;
        eprintln!("{} = {:?}", stringify!($expression), &value);
        value
    }};
}

fn main() {
    let mut calls = 0;
    let result = inspect_value!({
        calls += 1;
        String::from("payload")
    });
    assert_eq!(calls, 1);
    assert_eq!(result, "payload");
}
