use std::collections::VecDeque;

struct Ring<T, const N: usize> {
    slots: [Option<T>; N],
    head: usize,
    len: usize,
}

impl<T, const N: usize> Ring<T, N> {
    fn new() -> Self {
        Self {
            slots: std::array::from_fn(|_| None),
            head: 0,
            len: 0,
        }
    }

    fn push(&mut self, value: T) -> Result<(), T> {
        if self.len == N {
            return Err(value);
        }
        let tail = (self.head + self.len) % N;
        self.slots[tail] = Some(value);
        self.len += 1;
        Ok(())
    }

    fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            return None;
        }
        let value = self.slots[self.head].take();
        self.head = (self.head + 1) % N;
        self.len -= 1;
        value
    }
}

fn exercise<const N: usize>() {
    let mut ring = Ring::<u32, N>::new();
    let mut model = VecDeque::new();
    let mut state = 0x1234_5678_u64;
    for _ in 0..5_000 {
        state = state.wrapping_mul(6_364_136_223_846_793_005)
            .wrapping_add(1);
        let value = (state >> 32) as u32;
        if value & 1 == 0 {
            let actual = ring.push(value);
            let expected = if model.len() == N {
                Err(value)
            } else {
                model.push_back(value);
                Ok(())
            };
            assert_eq!(actual, expected);
        } else {
            assert_eq!(ring.pop(), model.pop_front());
        }
        assert_eq!(ring.len, model.len());
    }
    while let Some(expected) = model.pop_front() {
        assert_eq!(ring.pop(), Some(expected));
    }
    assert_eq!(ring.pop(), None);
}

fn main() {
    exercise::<0>();
    exercise::<1>();
    exercise::<2>();
    exercise::<7>();
}
