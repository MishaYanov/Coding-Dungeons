use std::sync::atomic::{AtomicUsize, Ordering};
use std::thread;

fn main() {
    let completed = AtomicUsize::new(0);
    thread::scope(|scope| {
        for _ in 0..4 {
            scope.spawn(|| {
                for _ in 0..1_000 {
                    completed.fetch_add(1, Ordering::Relaxed);
                }
            });
        }
    });
    assert_eq!(completed.load(Ordering::Relaxed), 4_000);
}
