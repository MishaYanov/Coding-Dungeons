use std::fmt::Display;

trait Source {
    type Item;
    type Error;

    fn next_item(&mut self) -> Result<Option<Self::Item>, Self::Error>;
}

fn summarize<S>(source: &mut S) -> Result<String, S::Error>
where
    S: Source,
    S::Item: Display,
{
    let mut result = String::new();
    while let Some(item) = source.next_item()? {
        if !result.is_empty() {
            result.push_str(", ");
        }
        result.push_str(&item.to_string());
    }
    Ok(result)
}
