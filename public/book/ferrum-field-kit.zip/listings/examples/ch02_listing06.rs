enum Event {
    Data { topic: String, bytes: Vec<u8> },
    Closed,
}

fn inspect(event: &Event) -> usize {
    match event {
        Event::Data { topic, bytes } => topic.len() + bytes.len(),
        Event::Closed => 0,
    }
}

fn extract(event: Event) -> Option<Vec<u8>> {
    match event {
        Event::Data { topic: _, bytes } => Some(bytes),
        Event::Closed => None,
    }
}

fn main() {
    let event = Event::Data {
        topic: String::from("updates"),
        bytes: vec![1, 2],
    };
    assert_eq!(inspect(&event), 9);
    assert_eq!(extract(event), Some(vec![1, 2]));
}
