use std::future;
use std::rc::Rc;

fn require_send<T: Send>(_: T) {}

async fn summarize() -> usize {
    let length = {
        let local = Rc::new(String::from("temporary"));
        local.len()
    };
    future::ready(()).await;
    length
}

fn main() {
    require_send(summarize());
}
