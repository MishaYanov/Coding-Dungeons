fn main() {
    let mut values = vec![10_usize, 20];
    values.push(values.len());
    assert_eq!(values, [10, 20, 2]);
}
