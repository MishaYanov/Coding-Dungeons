use std::cell::Cell;
use std::sync::{Arc, Mutex};

fn require_send<T: Send>() {}
fn require_sync<T: Sync>() {}

fn main() {
    require_send::<Cell<u32>>();
    require_send::<String>();
    require_sync::<String>();
    require_send::<Arc<Mutex<Vec<u8>>>>();
    require_sync::<Arc<Mutex<Vec<u8>>>>();
}
