struct Disconnected;

struct Connected {
    peer: String,
    sequence: u64,
}

struct Channel<S> {
    state: S,
}

impl Channel<Disconnected> {
    fn new() -> Self { Self { state: Disconnected } }

    fn connect(self, peer: String) -> Channel<Connected> {
        Channel { state: Connected { peer, sequence: 0 } }
    }
}

impl Channel<Connected> {
    fn frame(&mut self, payload: &str) -> String {
        let sequence = self.state.sequence;
        self.state.sequence = sequence.checked_add(1)
            .expect("sequence exhausted");
        format!("{}:{sequence}:{payload}", self.state.peer)
    }

    fn disconnect(self) -> Channel<Disconnected> {
        Channel { state: Disconnected }
    }
}
