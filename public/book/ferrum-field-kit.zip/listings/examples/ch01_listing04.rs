#[derive(Clone, Copy)]
struct Position {
    byte: usize,
    line: usize,
}

struct Reservation {
    id: u64,
}

fn commit(reservation: Reservation) -> u64 {
    reservation.id
}

fn main() {
    let start = Position { byte: 0, line: 1 };
    let checkpoint = start;
    assert_eq!(start.byte, checkpoint.byte);
    assert_eq!(start.line, 1);
    let ticket = Reservation { id: 42 };
    assert_eq!(commit(ticket), 42);
}
