use std::io::{self, Write};

struct RecordWriter<W: Write> {
    output: W,
    records: usize,
}

impl<W: Write> RecordWriter<W> {
    fn new(output: W) -> Self {
        Self { output, records: 0 }
    }

    fn write_record(&mut self, bytes: &[u8]) -> io::Result<()> {
        self.output.write_all(bytes)?;
        self.output.write_all(b"\n")?;
        self.records += 1;
        Ok(())
    }

    fn finish(mut self) -> io::Result<(W, usize)> {
        self.output.flush()?;
        Ok((self.output, self.records))
    }
}

fn main() -> io::Result<()> {
    let mut writer = RecordWriter::new(Vec::<u8>::new());
    writer.write_record(b"alpha")?;
    let (bytes, count) = writer.finish()?;
    assert_eq!(count, 1);
    assert_eq!(bytes, b"alpha\n");
    Ok(())
}
