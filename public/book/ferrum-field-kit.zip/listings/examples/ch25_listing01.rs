use std::future::Future;
use std::sync::{Arc, Condvar, Mutex};
use std::task::{Context, Poll, Wake, Waker};

struct Signal {
    notified: Mutex<bool>,
    changed: Condvar,
}

impl Signal {
    fn notify(&self) {
        *self.notified.lock().unwrap() = true;
        self.changed.notify_one();
    }

    fn wait(&self) {
        let mut notified = self.notified.lock().unwrap();
        while !*notified {
            notified = self.changed.wait(notified).unwrap();
        }
        *notified = false;
    }
}

impl Wake for Signal {
    fn wake(self: Arc<Self>) {
        self.notify();
    }

    fn wake_by_ref(self: &Arc<Self>) {
        self.notify();
    }
}

fn run<F: Future>(future: F) -> F::Output {
    let signal = Arc::new(Signal {
        notified: Mutex::new(false),
        changed: Condvar::new(),
    });
    let waker = Waker::from(Arc::clone(&signal));
    let mut context = Context::from_waker(&waker);
    let mut future = Box::pin(future);
    loop {
        match future.as_mut().poll(&mut context) {
            Poll::Ready(output) => return output,
            Poll::Pending => signal.wait(),
        }
    }
}

fn main() {
    assert_eq!(run(async { 6 * 7 }), 42);
}
