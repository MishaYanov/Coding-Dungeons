const fn parse_port(input: &[u8]) -> Option<u16> {
    if input.is_empty() {
        return None;
    }
    let mut value = 0_u16;
    let mut index = 0;
    while index < input.len() {
        let byte = input[index];
        if byte < b'0' || byte > b'9' {
            return None;
        }
        value = match value.checked_mul(10) {
            Some(value) => value,
            None => return None,
        };
        value = match value.checked_add((byte - b'0') as u16) {
            Some(value) => value,
            None => return None,
        };
        index += 1;
    }
    Some(value)
}

const DEFAULT_PORT: u16 = match parse_port(b"8080") {
    Some(port) => port,
    None => panic!("invalid default port"),
};

fn main() {
    assert_eq!(DEFAULT_PORT, 8080);
    let dynamic = String::from("65535");
    assert_eq!(parse_port(dynamic.as_bytes()), Some(65535));
    assert_eq!(parse_port(b"65536"), None);
}
