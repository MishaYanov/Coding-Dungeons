use std::alloc::{alloc, dealloc, handle_alloc_error, Layout};
use std::mem::ManuallyDrop;
use std::ops::{Deref, DerefMut};
use std::ptr::NonNull;

struct OwnedWord {
    pointer: NonNull<u64>,
}

impl OwnedWord {
    fn new(value: u64) -> Self {
        let layout = Layout::new::<u64>();
        // SAFETY: u64 has a nonzero valid allocation layout.
        let raw = unsafe { alloc(layout) };
        let pointer = match NonNull::new(raw.cast::<u64>()) {
            Some(pointer) => pointer,
            None => handle_alloc_error(layout),
        };
        // SAFETY: allocation has sufficient size and alignment and
        // is uniquely owned. write initializes its sole value.
        unsafe { pointer.as_ptr().write(value) };
        Self { pointer }
    }

    fn into_inner(self) -> u64 {
        let owner = ManuallyDrop::new(self);
        // SAFETY: the invariant supplies one initialized value.
        let value = unsafe { owner.pointer.as_ptr().read() };
        // SAFETY: this consumes the sole allocation ownership using
        // the same allocator and layout that created the block.
        unsafe {
            dealloc(owner.pointer.as_ptr().cast(), Layout::new::<u64>());
        }
        value
    }
}

impl Deref for OwnedWord {
    type Target = u64;

    fn deref(&self) -> &u64 {
        // SAFETY: the invariant supplies an initialized live value,
        // and shared owner access prevents conflicting mutation.
        unsafe { self.pointer.as_ref() }
    }
}

impl DerefMut for OwnedWord {
    fn deref_mut(&mut self) -> &mut u64 {
        // SAFETY: exclusive owner access supplies unique access to
        // its sole initialized value for this borrow.
        unsafe { self.pointer.as_mut() }
    }
}

impl Drop for OwnedWord {
    fn drop(&mut self) {
        // SAFETY: this owner still owns the allocation. u64 needs
        // no destructor, and deallocation uses the original layout.
        unsafe {
            dealloc(self.pointer.as_ptr().cast(), Layout::new::<u64>());
        }
    }
}

fn main() {
    let mut value = OwnedWord::new(40);
    *value += 2;
    assert_eq!(*value, 42);
    assert_eq!(value.into_inner(), 42);
}
