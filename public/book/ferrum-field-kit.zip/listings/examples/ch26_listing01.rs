use std::cell::Cell;
use std::future::{self, Future};
use std::rc::Rc;
use std::task::{Context, Poll, Waker};

struct Pool {
    free: Rc<Cell<usize>>,
}

struct Permit {
    free: Rc<Cell<usize>>,
}

impl Pool {
    fn take(&self) -> Option<Permit> {
        let available = self.free.get();
        if available == 0 {
            return None;
        }
        self.free.set(available - 1);
        Some(Permit { free: Rc::clone(&self.free) })
    }
}

impl Drop for Permit {
    fn drop(&mut self) {
        self.free.set(self.free.get() + 1);
    }
}

async fn hold(pool: &Pool) {
    let _permit = pool.take().expect("capacity available");
    future::pending::<()>().await;
}

fn main() {
    let pool = Pool { free: Rc::new(Cell::new(1)) };
    let mut operation = Box::pin(hold(&pool));
    assert_eq!(pool.free.get(), 1);
    let mut context = Context::from_waker(Waker::noop());
    assert_eq!(operation.as_mut().poll(&mut context), Poll::Pending);
    assert_eq!(pool.free.get(), 0);
    drop(operation);
    assert_eq!(pool.free.get(), 1);
}
