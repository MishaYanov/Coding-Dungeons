use std::future::{self, Future};

fn prepare(
    text: String,
) -> Result<impl Future<Output = usize>, &'static str> {
    if text.is_empty() {
        return Err("empty input");
    }
    Ok(async move {
        future::ready(()).await;
        text.len()
    })
}

async fn deferred_check(text: String) -> Result<usize, &'static str> {
    if text.is_empty() {
        return Err("empty input");
    }
    Ok(text.len())
}
