use std::mem::{align_of, size_of};
use std::num::NonZeroU32;

#[repr(transparent)]
#[derive(Clone, Copy)]
struct RequestId(NonZeroU32);

impl RequestId {
    fn new(raw: u32) -> Option<Self> {
        NonZeroU32::new(raw).map(Self)
    }

    fn get(self) -> u32 {
        self.0.get()
    }
}

fn main() {
    assert_eq!(size_of::<RequestId>(), size_of::<NonZeroU32>());
    assert_eq!(align_of::<RequestId>(), align_of::<NonZeroU32>());
    assert_eq!(RequestId::new(9).unwrap().get(), 9);
    assert!(RequestId::new(0).is_none());
}
