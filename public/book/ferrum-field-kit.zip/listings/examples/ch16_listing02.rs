mod private {
    pub trait Sealed {}
}

pub trait WireInteger: private::Sealed + Copy {
    fn append_be(self, output: &mut Vec<u8>);
}

impl private::Sealed for u16 {}
impl private::Sealed for u32 {}

impl WireInteger for u16 {
    fn append_be(self, output: &mut Vec<u8>) {
        output.extend_from_slice(&self.to_be_bytes());
    }
}

impl WireInteger for u32 {
    fn append_be(self, output: &mut Vec<u8>) {
        output.extend_from_slice(&self.to_be_bytes());
    }
}

pub fn encode<T: WireInteger>(value: T) -> Vec<u8> {
    let mut output = Vec::new();
    value.append_be(&mut output);
    output
}
