use std::fmt::{self, Display};

struct Redacted<T>(T);

impl<T> Display for Redacted<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("[redacted]")
    }
}

struct CommaSeparated<'a>(&'a [u32]);

impl Display for CommaSeparated<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for (index, value) in self.0.iter().enumerate() {
            if index != 0 {
                f.write_str(",")?;
            }
            write!(f, "{value}")?;
        }
        Ok(())
    }
}

fn main() {
    let secret = Redacted("access token");
    assert_eq!(secret.to_string(), "[redacted]");
    assert_eq!(CommaSeparated(&[2, 3, 5]).to_string(), "2,3,5");
}
