use std::sync::mpsc::{self, TrySendError};

fn main() {
    let (sender, receiver) = mpsc::sync_channel(1);
    sender.send(String::from("first")).unwrap();
    let rejected = match sender.try_send(String::from("second")) {
        Ok(()) => panic!("the queue should be full"),
        Err(TrySendError::Full(job)) => job,
        Err(TrySendError::Disconnected(_)) => panic!("no receiver"),
    };
    assert_eq!(rejected, "second");
    assert_eq!(receiver.recv().unwrap(), "first");
    sender.send(rejected).unwrap();
    assert_eq!(receiver.recv().unwrap(), "second");
}
