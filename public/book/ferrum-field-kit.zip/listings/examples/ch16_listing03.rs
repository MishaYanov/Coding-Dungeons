#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[non_exhaustive]
pub enum CacheOutcome {
    Hit,
    Miss,
    Bypassed,
}

pub struct CacheReport {
    outcome: CacheOutcome,
    bytes: usize,
}

impl CacheReport {
    pub fn outcome(&self) -> CacheOutcome { self.outcome }
    pub fn bytes(&self) -> usize { self.bytes }
}
