trait Destination {
    fn write(&mut self, bytes: &[u8]);

    fn empty() -> Self
    where
        Self: Sized;

    fn write_value<T: AsRef<[u8]>>(&mut self, value: T)
    where
        Self: Sized,
    {
        self.write(value.as_ref());
    }
}

struct Buffer(Vec<u8>);

impl Destination for Buffer {
    fn write(&mut self, bytes: &[u8]) {
        self.0.extend_from_slice(bytes);
    }

    fn empty() -> Self { Self(Vec::new()) }
}

fn main() {
    let mut buffer = Buffer::empty();
    buffer.write_value("hello");
    let destination: &mut dyn Destination = &mut buffer;
    destination.write(b" world");
    assert_eq!(buffer.0, b"hello world");
}
