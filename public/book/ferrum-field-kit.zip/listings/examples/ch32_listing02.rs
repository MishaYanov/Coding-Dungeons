use std::mem::{ManuallyDrop, MaybeUninit};

struct Prefix<T, const N: usize> {
    storage: [MaybeUninit<T>; N],
    len: usize,
}

impl<T, const N: usize> Prefix<T, N> {
    fn new() -> Self {
        Self {
            storage: [const { MaybeUninit::uninit() }; N],
            len: 0,
        }
    }

    fn push(&mut self, value: T) -> Result<(), T> {
        if self.len == N {
            return Err(value);
        }
        self.storage[self.len].write(value);
        self.len += 1;
        Ok(())
    }

    fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            return None;
        }
        self.len -= 1;
        // SAFETY: the previous initialized prefix included this
        // slot. Decrementing len removes its old drop obligation.
        Some(unsafe { self.storage[self.len].assume_init_read() })
    }

    fn as_slice(&self) -> &[T] {
        // SAFETY: exactly this prefix contains initialized T values.
        // Array storage is aligned and contiguous, and the returned
        // shared borrow is tied to this owner.
        unsafe {
            std::slice::from_raw_parts(
                self.storage.as_ptr().cast::<T>(),
                self.len,
            )
        }
    }

    fn into_array(self) -> Result<[T; N], Self> {
        if self.len != N {
            return Err(self);
        }
        let owner = ManuallyDrop::new(self);
        // SAFETY: every element is initialized, array layouts match,
        // and suppressing owner Drop transfers each value exactly once.
        let array = unsafe {
            owner.storage.as_ptr().cast::<[T; N]>().read()
        };
        Ok(array)
    }
}

impl<T, const N: usize> Drop for Prefix<T, N> {
    fn drop(&mut self) {
        while let Some(value) = self.pop() {
            drop(value);
        }
    }
}

fn main() {
    let mut prefix = Prefix::<String, 2>::new();
    assert!(prefix.push(String::from("left")).is_ok());
    assert_eq!(prefix.as_slice(), &[String::from("left")]);
    assert!(prefix.push(String::from("right")).is_ok());
    assert!(prefix.push(String::from("overflow")).is_err());
    let values = match prefix.into_array() {
        Ok(values) => values,
        Err(_) => panic!("expected a complete array"),
    };
    assert_eq!(values, [String::from("left"), String::from("right")]);
}
