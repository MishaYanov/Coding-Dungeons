use std::sync::mpsc;

fn main() {
    let (sender, receiver) = mpsc::channel::<String>();
    drop(receiver);
    let message = String::from("retain on failure");
    let recovered = sender.send(message).unwrap_err().0;
    assert_eq!(recovered, "retain on failure");
}
