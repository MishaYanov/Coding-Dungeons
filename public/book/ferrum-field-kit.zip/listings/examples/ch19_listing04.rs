use std::thread;

fn scale(values: &mut [i64], factor: i64) {
    let middle = values.len() / 2;
    let (left, right) = values.split_at_mut(middle);
    thread::scope(|scope| {
        scope.spawn(move || {
            for value in left {
                *value *= factor;
            }
        });
        scope.spawn(move || {
            for value in right {
                *value *= factor;
            }
        });
    });
}

fn main() {
    let mut values = [1, 2, 3, 4, 5];
    scale(&mut values, 3);
    assert_eq!(values, [3, 6, 9, 12, 15]);
}
