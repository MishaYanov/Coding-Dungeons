use std::ops::Range;

struct StoredRecord {
    source: String,
    name: Range<usize>,
    value: Range<usize>,
}

impl StoredRecord {
    fn parse(source: String) -> Result<Self, String> {
        let Some(eq) = source.find('=') else {
            return Err(source);
        };
        let left = &source[..eq];
        let right = &source[eq + 1..];
        let name_start = left.len() - left.trim_start().len();
        let name_end = left.trim_end().len();
        let value_start = eq + 1
            + right.len() - right.trim_start().len();
        let value_end = eq + 1 + right.trim_end().len();
        if name_start >= name_end || value_start >= value_end {
            return Err(source);
        }
        Ok(Self {
            source,
            name: name_start..name_end,
            value: value_start..value_end,
        })
    }

    fn fields(&self) -> (&str, &str) {
        (&self.source[self.name.clone()],
         &self.source[self.value.clone()])
    }
}

fn main() {
    let record = StoredRecord::parse("  theme = dark ".into())
        .ok().unwrap();
    let moved = Box::new(record);
    assert_eq!(moved.fields(), ("theme", "dark"));
}
