use std::sync::mpsc::sync_channel;
use std::thread;

#[derive(Debug, Default)]
struct Summary {
    completed: usize,
    job_failures: usize,
    sum: u64,
    sum_overflowed: bool,
}

fn run(jobs: u64, worker_count: usize)
    -> Result<Summary, &'static str>
{
    if worker_count == 0 {
        return Err("at least one worker is required");
    }
    thread::scope(|scope| {
        let (result_tx, result_rx) = sync_channel::<Option<u64>>(8);
        let collector = scope.spawn(move || {
            let mut summary = Summary::default();
            for result in result_rx {
                match result {
                    Some(value) => {
                        summary.completed += 1;
                        match summary.sum.checked_add(value) {
                            Some(sum) => summary.sum = sum,
                            None => summary.sum_overflowed = true,
                        }
                    }
                    None => summary.job_failures += 1,
                }
            }
            summary
        });

        let mut senders = Vec::new();
        let mut workers = Vec::new();
        for _ in 0..worker_count {
            let (job_tx, job_rx) = sync_channel::<u64>(2);
            senders.push(job_tx);
            let output = result_tx.clone();
            workers.push(scope.spawn(move || {
                for value in job_rx {
                    let result = value.checked_mul(value);
                    if output.send(result).is_err() {
                        break;
                    }
                }
            }));
        }
        drop(result_tx);

        let mut dispatch_failed = false;
        let mut next = 0;
        for value in 0..jobs {
            if senders[next].send(value).is_err() {
                dispatch_failed = true;
                break;
            }
            next = (next + 1) % worker_count;
        }
        drop(senders);

        let worker_panics: Vec<_> = workers.into_iter()
            .filter_map(|worker| worker.join().err())
            .collect();
        let summary = collector.join()
            .map_err(|_| "collector panicked")?;
        if dispatch_failed || !worker_panics.is_empty() {
            Err("worker failed before pipeline completion")
        } else {
            Ok(summary)
        }
    })
}

fn main() {
    let summary = run(10, 3).unwrap();
    assert_eq!(summary.completed, 10);
    assert_eq!(summary.job_failures, 0);
    assert_eq!(summary.sum, 285);
    assert!(!summary.sum_overflowed);
}
