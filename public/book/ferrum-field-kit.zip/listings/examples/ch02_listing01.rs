struct Job {
    label: String,
    data: Vec<u8>,
}

fn main() {
    let job = Job {
        label: String::from("export"),
        data: vec![1, 2, 3],
    };
    let label = job.label;
    assert_eq!(job.data.len(), 3);
    assert_eq!(label, "export");
}
