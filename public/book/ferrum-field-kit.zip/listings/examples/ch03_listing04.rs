fn two_mut<T>(
    values: &mut [T],
    first: usize,
    second: usize,
) -> Option<(&mut T, &mut T)> {
    if first == second || first >= values.len() {
        return None;
    }
    if second >= values.len() {
        return None;
    }
    if first < second {
        let (left, right) = values.split_at_mut(second);
        Some((&mut left[first], &mut right[0]))
    } else {
        let (left, right) = values.split_at_mut(first);
        Some((&mut right[0], &mut left[second]))
    }
}

fn main() {
    let mut balances = [100_i64, 40, 75];
    let (source, target) = two_mut(&mut balances, 0, 2).unwrap();
    *source -= 10;
    *target += 10;
    assert_eq!(balances, [90, 40, 85]);
}
