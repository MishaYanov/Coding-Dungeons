#[derive(Debug, PartialEq)]
struct WireHeader {
    kind: u8,
    length: u32,
    flags: u16,
}

fn decode_header(bytes: &[u8]) -> Option<WireHeader> {
    let bytes = bytes.get(..7)?;
    let length = u32::from_le_bytes(bytes[1..5].try_into().ok()?);
    let flags = u16::from_le_bytes(bytes[5..7].try_into().ok()?);
    Some(WireHeader { kind: bytes[0], length, flags })
}

fn main() {
    let header = decode_header(&[2, 4, 0, 0, 0, 1, 0]).unwrap();
    assert_eq!(header, WireHeader { kind: 2, length: 4, flags: 1 });
    assert!(decode_header(&[2, 4]).is_none());
}
