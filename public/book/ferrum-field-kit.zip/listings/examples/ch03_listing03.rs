struct Encoder {
    prefix: String,
    output: Vec<u8>,
    records: usize,
}

impl Encoder {
    fn write_record(&mut self, record: &[u8]) {
        let prefix = &self.prefix;
        let output = &mut self.output;
        output.extend_from_slice(prefix.as_bytes());
        output.extend_from_slice(record);
        output.push(b'\n');
        self.records += 1;
    }

    fn split(&mut self) -> (&str, &mut Vec<u8>) {
        (&self.prefix, &mut self.output)
    }
}

fn main() {
    let mut encoder = Encoder {
        prefix: String::from("item="),
        output: Vec::new(),
        records: 0,
    };
    encoder.write_record(b"42");
    let (prefix, output) = encoder.split();
    assert_eq!(prefix, "item=");
    output.extend_from_slice(b"done\n");
}
