#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct Handle {
    slot: usize,
    generation: u64,
}

struct Slot<T> {
    generation: u64,
    value: Option<T>,
}

struct Arena<T> {
    slots: Vec<Slot<T>>,
    free: Vec<usize>,
}

impl<T> Arena<T> {
    fn new() -> Self {
        Self { slots: Vec::new(), free: Vec::new() }
    }

    fn insert(&mut self, value: T) -> Handle {
        if let Some(index) = self.free.pop() {
            let slot = &mut self.slots[index];
            slot.value = Some(value);
            Handle { slot: index, generation: slot.generation }
        } else {
            let index = self.slots.len();
            self.slots.push(Slot { generation: 0, value: Some(value) });
            Handle { slot: index, generation: 0 }
        }
    }

    fn get(&self, handle: Handle) -> Option<&T> {
        let slot = self.slots.get(handle.slot)?;
        if slot.generation != handle.generation {
            return None;
        }
        slot.value.as_ref()
    }

    fn remove(&mut self, handle: Handle) -> Option<T> {
        let slot = self.slots.get_mut(handle.slot)?;
        if slot.generation != handle.generation {
            return None;
        }
        let value = slot.value.take()?;
        if let Some(next) = slot.generation.checked_add(1) {
            slot.generation = next;
            self.free.push(handle.slot);
        }
        Some(value)
    }
}

fn main() {
    let mut arena = Arena::new();
    let old = arena.insert(String::from("old"));
    assert_eq!(arena.remove(old).as_deref(), Some("old"));
    let new = arena.insert(String::from("new"));
    assert_eq!(old.slot, new.slot);
    assert_ne!(old.generation, new.generation);
    assert!(arena.get(old).is_none());
    assert_eq!(arena.get(new).map(String::as_str), Some("new"));
}
