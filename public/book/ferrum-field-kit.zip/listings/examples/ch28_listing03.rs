use std::time::{Duration, Instant};

#[derive(Clone, Copy)]
struct Budget {
    deadline: Instant,
}

impl Budget {
    fn from_now(duration: Duration) -> Option<Self> {
        Instant::now().checked_add(duration)
            .map(|deadline| Self { deadline })
    }

    fn remaining(self) -> Option<Duration> {
        self.deadline.checked_duration_since(Instant::now())
            .filter(|duration| !duration.is_zero())
    }
}
