use std::collections::{BTreeMap, VecDeque};

const RECORD_LIMIT: usize = 4;

#[derive(Debug)]
struct Request<'a> { id: &'a str, units: u64 }

#[derive(Debug)]
struct Job { id: String, units: u64 }

fn valid_id(id: &str) -> bool {
    !id.is_empty() && id.len() <= 16
        && id.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'-')
}

fn parse(line: &str) -> Result<Request<'_>, &'static str> {
    if line.len() > 40 { return Err("command too long"); }
    let (id, number) = line.split_once('=').ok_or("missing =")?;
    if !valid_id(id) || number.is_empty()
        || !number.bytes().all(|b| b.is_ascii_digit()) {
        return Err("invalid command");
    }
    let units = number.parse::<u64>().map_err(|_| "invalid units")?;
    if !(1..=1000).contains(&units) { return Err("invalid units"); }
    Ok(Request { id, units })
}

impl Request<'_> {
    fn into_job(self) -> Job {
        Job { id: self.id.to_owned(), units: self.units }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Phase { Pending, Unknown, Done(u64) }

#[derive(Clone, Copy)]
struct Entry { units: u64, phase: Phase }

#[derive(Debug)]
enum Admission { Queued, Busy(Job), Replay(u64) }

struct Peer {
    receipts: BTreeMap<String, (u64, u64)>,
    lookup_available: bool,
}

impl Peer {
    fn new() -> Self {
        Self { receipts: BTreeMap::new(), lookup_available: true }
    }

    fn send(&mut self, job: &Job, lose_ack: bool) -> Option<u64> {
        let next_receipt = 100 + self.receipts.len() as u64;
        let (units, receipt) = *self.receipts.entry(job.id.clone())
            .or_insert((job.units, next_receipt));
        assert_eq!(units, job.units, "peer key must preserve meaning");
        if lose_ack { None } else { Some(receipt) }
    }

    fn status(&self, job: &Job) -> Option<u64> {
        if !self.lookup_available { return None; }
        self.receipts.get(&job.id).and_then(|&(units, receipt)| {
            (units == job.units).then_some(receipt)
        })
    }
}

struct Dispatch {
    accepting: bool,
    limit: usize,
    revision: u64,
    entries: BTreeMap<String, Entry>,
    queue: VecDeque<Job>,
}

#[derive(Debug)]
struct Report {
    accepted: usize,
    done: usize,
    unknown: usize,
    pending: usize,
    stopped: bool,
}

impl Dispatch {
    fn new(limit: usize) -> Self {
        assert!((1..=RECORD_LIMIT).contains(&limit));
        Self { accepting: true, limit, revision: 0,
            entries: BTreeMap::new(),
            queue: VecDeque::with_capacity(limit) }
    }

    fn submit(&mut self, expected: u64, job: Job)
        -> Result<Admission, (&'static str, Job)>
    {
        if expected != self.revision { return Err(("stale version", job)); }
        if !valid_id(&job.id) || !(1..=1000).contains(&job.units) {
            return Err(("invalid job", job));
        }
        if let Some(entry) = self.entries.get(&job.id) {
            if entry.units != job.units {
                return Err(("payload conflict", job));
            }
            return Ok(match entry.phase {
                Phase::Done(receipt) => Admission::Replay(receipt),
                _ => Admission::Busy(job),
            });
        }
        if !self.accepting { return Err(("closed", job)); }
        if self.queue.len() == self.limit { return Err(("full", job)); }
        if self.entries.len() == RECORD_LIMIT {
            return Err(("ledger full", job));
        }
        self.entries.insert(job.id.clone(), Entry {
            units: job.units, phase: Phase::Pending,
        });
        self.queue.push_back(job);
        self.revision += 1;
        Ok(Admission::Queued)
    }

    fn step(&mut self, peer: &mut Peer, lose_ack: bool) {
        let Some(job) = self.queue.pop_front() else { return; };
        let entry = self.entries.get_mut(&job.id).expect("queued entry");
        let next = match entry.phase {
            Phase::Pending => match peer.send(&job, lose_ack) {
                Some(receipt) => Phase::Done(receipt),
                None => Phase::Unknown,
            },
            Phase::Unknown => match peer.status(&job) {
                Some(receipt) => Phase::Done(receipt),
                None => Phase::Unknown,
            },
            Phase::Done(_) => unreachable!("completed job in queue"),
        };
        if next != entry.phase {
            entry.phase = next;
            self.revision += 1;
        }
        if !matches!(next, Phase::Done(_)) { self.queue.push_back(job); }
    }

    fn close_and_drain(&mut self, peer: &mut Peer) -> Report {
        self.accepting = false;
        // One bounded pass; unavailable status cannot cause infinite retry.
        for _ in 0..self.queue.len() { self.step(peer, false); }
        self.report()
    }

    fn report(&self) -> Report {
        let mut report = Report { accepted: self.entries.len(), done: 0,
            unknown: 0, pending: 0,
            stopped: !self.accepting && self.queue.is_empty() };
        for entry in self.entries.values() {
            match entry.phase {
                Phase::Pending => report.pending += 1,
                Phase::Unknown => report.unknown += 1,
                Phase::Done(_) => report.done += 1,
            }
        }
        assert_eq!(self.queue.len(), report.pending + report.unknown);
        assert_eq!(report.accepted,
            report.done + report.pending + report.unknown);
        report
    }
}

fn job(text: &str) -> Job { parse(text).unwrap().into_job() }

fn main() {
    let source = String::from("K7=12");
    let owned = parse(&source).unwrap().into_job();
    drop(source); // The queued request no longer borrows this buffer.
    let mut service = Dispatch::new(2);
    let mut peer = Peer::new();
    assert!(matches!(service.submit(0, owned), Ok(Admission::Queued)));

    let (reason, returned) = service.submit(0, job("K8=3")).unwrap_err();
    assert_eq!(reason, "stale version");
    assert_eq!(returned.id, "K8");
    assert!(matches!(service.submit(service.revision, returned),
        Ok(Admission::Queued)));
    assert_eq!(service.submit(service.revision, job("K9=1"))
        .unwrap_err().0, "full");

    // Peer applied K7, but its reply was lost.
    service.step(&mut peer, true);
    assert_eq!(peer.receipts.len(), 1);
    assert_eq!(service.report().unknown, 1);
    match service.submit(service.revision, job("K7=012")).unwrap() {
        Admission::Busy(returned) => assert_eq!(returned.units, 12),
        _ => panic!("uncertain work must not be sent again"),
    }
    assert_eq!(service.submit(service.revision, job("K7=13"))
        .unwrap_err().0, "payload conflict");

    let report = service.close_and_drain(&mut peer);
    assert!(report.stopped);
    assert_eq!((report.accepted, report.done, report.unknown), (2, 2, 0));
    assert_eq!(peer.receipts.len(), 2);
    assert!(matches!(service.submit(service.revision, job("K7=12")),
        Ok(Admission::Replay(100))));
    assert_eq!(service.submit(service.revision, job("K9=1"))
        .unwrap_err().0, "closed");

    let mut unresolved = Dispatch::new(1);
    let mut unavailable_peer = Peer::new();
    unresolved.submit(0, job("U1=5")).unwrap();
    unresolved.step(&mut unavailable_peer, true);
    unavailable_peer.lookup_available = false;
    let report = unresolved.close_and_drain(&mut unavailable_peer);
    assert!(!report.stopped);
    assert_eq!((report.accepted, report.done, report.unknown), (1, 0, 1));

    let mut bad_retry = Peer::new();
    assert!(bad_retry.send(&job("old-key=12"), true).is_none());
    assert!(bad_retry.send(&job("new-key=12"), false).is_some());
    // A new key caused a second effect.
    assert_eq!(bad_retry.receipts.len(), 2);
    assert!(parse("K7=0").is_err());
    assert!(parse("K7=18446744073709551616").is_err());
    println!("dispatch: conflicts, lost reply, replay and drain checked");
}
