fn copy_prefix(destination: &mut [u8], source: &[u8]) -> bool {
    if source.len() > destination.len() {
        return false;
    }
    // SAFETY: safe slice inputs establish live initialized ranges.
    // The exclusive destination cannot conflict with source, and
    // the checked destination range is large enough for this copy.
    unsafe {
        std::ptr::copy_nonoverlapping(
            source.as_ptr(),
            destination.as_mut_ptr(),
            source.len(),
        );
    }
    true
}

fn main() {
    let mut bytes = [0_u8; 4];
    assert!(copy_prefix(&mut bytes, &[7, 8]));
    assert_eq!(bytes, [7, 8, 0, 0]);
}
