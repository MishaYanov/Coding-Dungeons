#[derive(Debug, PartialEq)]
struct Header<'a> {
    key: &'a str,
    value: &'a str,
}

fn parse_header(input: &str) -> Option<Header<'_>> {
    let (key, value) = input.split_once(':')?;
    Some(Header { key: key.trim(), value: value.trim() })
}

fn owned_key(input: &str) -> Option<String> {
    Some(parse_header(input)?.key.to_owned())
}

fn main() {
    let message = String::from("mode: strict");
    let header = parse_header(&message).unwrap();
    assert_eq!(header.value, "strict");
    let key = owned_key(&message).unwrap();
    drop(message);
    assert_eq!(key, "mode");
}
