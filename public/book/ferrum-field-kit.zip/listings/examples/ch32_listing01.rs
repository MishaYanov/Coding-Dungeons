use std::mem::MaybeUninit;

fn main() {
    let mut storage = MaybeUninit::<String>::uninit();
    storage.write(String::from("prepared"));
    // SAFETY: write established a valid String and nothing has moved
    // or dropped that value since initialization.
    let value = unsafe { storage.assume_init() };
    assert_eq!(value, "prepared");
}
