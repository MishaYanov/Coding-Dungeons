trait Producer {
    type Item;
    fn produce(&mut self) -> Option<Self::Item>;
}

trait Consumer<T> {
    fn consume(&mut self, item: T);
}

struct Countdown(u8);

impl Producer for Countdown {
    type Item = u8;

    fn produce(&mut self) -> Option<u8> {
        if self.0 == 0 {
            None
        } else {
            self.0 -= 1;
            Some(self.0)
        }
    }
}

#[derive(Default)]
struct Sum(u64);

impl Consumer<u8> for Sum {
    fn consume(&mut self, item: u8) {
        self.0 += u64::from(item);
    }
}

fn drain<P, C>(producer: &mut P, consumer: &mut C)
where
    P: Producer,
    C: Consumer<P::Item>,
{
    while let Some(item) = producer.produce() {
        consumer.consume(item);
    }
}

fn main() {
    let mut producer = Countdown(4);
    let mut sum = Sum::default();
    drain(&mut producer, &mut sum);
    assert_eq!(sum.0, 6);
}
