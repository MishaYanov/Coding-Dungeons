use std::future::Future;
use std::pin::Pin;
use std::task::{Context, Poll};

struct Map<F, G> {
    inner: Pin<Box<F>>,
    map: Option<G>,
}

impl<F, G> Map<F, G> {
    fn new(inner: F, map: G) -> Self {
        Self {
            inner: Box::pin(inner),
            map: Some(map),
        }
    }
}

impl<F, G, U> Future for Map<F, G>
where
    F: Future,
    G: FnOnce(F::Output) -> U + Unpin,
{
    type Output = U;

    fn poll(
        self: Pin<&mut Self>,
        context: &mut Context<'_>,
    ) -> Poll<U> {
        let this = self.get_mut();
        match this.inner.as_mut().poll(context) {
            Poll::Pending => Poll::Pending,
            Poll::Ready(value) => {
                let map = this.map.take().expect("polled after completion");
                Poll::Ready(map(value))
            }
        }
    }
}

fn main() {
    let future = Map::new(async { 4_u32 }, |value| value * 3);
    let mut future = Box::pin(future);
    let mut context = Context::from_waker(std::task::Waker::noop());
    assert_eq!(future.as_mut().poll(&mut context), Poll::Ready(12));
}
