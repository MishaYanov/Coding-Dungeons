#[derive(Debug, PartialEq, Eq)]
enum RenameError {
    Empty,
    TooLong,
}

struct Account {
    name: String,
    revision: u64,
}

impl Account {
    fn rename(&mut self, input: &str) -> Result<(), RenameError> {
        let normalized = input.trim();
        if normalized.is_empty() {
            return Err(RenameError::Empty);
        }
        if normalized.len() > 64 {
            return Err(RenameError::TooLong);
        }
        let next = normalized.to_owned();
        let revision = self.revision.checked_add(1)
            .expect("account revision exhausted");
        self.name = next;
        self.revision = revision;
        Ok(())
    }
}
