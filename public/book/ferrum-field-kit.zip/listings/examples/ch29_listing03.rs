#[repr(C, packed)]
struct PackedHeader {
    kind: u8,
    length: u32,
}

fn main() {
    let header = PackedHeader { kind: 1, length: 0x0102_0304 };
    let pointer = &raw const header.length;
    // SAFETY: the field is initialized and readable; alignment is
    // handled by read_unaligned rather than by a reference.
    let length = unsafe { pointer.read_unaligned() };
    assert_eq!(length, 0x0102_0304);
}
