#[doc(hidden)]
pub mod __macro_support {
    pub fn checked_sum(values: &[u64]) -> Option<u64> {
        values.iter().try_fold(0_u64, |sum, value| {
            sum.checked_add(*value)
        })
    }
}

#[macro_export]
macro_rules! checked_sum {
    ($($value:expr),* $(,)?) => {{
        $crate::__macro_support::checked_sum(&[$($value),*])
    }};
}

fn main() {
    assert_eq!(checked_sum!(2, 3, 5), Some(10));
    assert_eq!(checked_sum!(u64::MAX, 1), None);
}
