fn use_once<F, T>(operation: F) -> T
where
    F: FnOnce() -> T,
{
    operation()
}

fn use_twice<F>(mut operation: F) -> (usize, usize)
where
    F: FnMut() -> usize,
{
    (operation(), operation())
}

fn main() {
    let message = String::from("owned result");
    let result = use_once(move || message);
    assert_eq!(result, "owned result");

    let mut count = 0;
    let values = use_twice(|| {
        count += 1;
        count
    });
    assert_eq!(values, (1, 2));
    assert_eq!(count, 2);
}
