#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct AccountId(String);

#[derive(Debug, PartialEq, Eq)]
enum AccountIdError {
    Empty,
    InvalidByte { index: usize },
}

impl AccountId {
    fn parse(value: String) -> Result<Self, AccountIdError> {
        if value.is_empty() {
            return Err(AccountIdError::Empty);
        }
        if let Some(index) = value.bytes().position(|byte| {
            !(byte.is_ascii_alphanumeric() || byte == b'_')
        }) {
            return Err(AccountIdError::InvalidByte { index });
        }
        Ok(Self(value))
    }

    fn as_str(&self) -> &str { &self.0 }

    fn into_string(self) -> String { self.0 }
}

fn main() {
    let id = AccountId::parse("build_42".into()).unwrap();
    assert_eq!(id.as_str(), "build_42");
    assert_eq!(AccountId::parse("".into()), Err(AccountIdError::Empty));
}
