use std::marker::PhantomData;

struct Id<T> {
    index: usize,
    kind: PhantomData<fn() -> T>,
}

impl<T> Id<T> {
    fn new(index: usize) -> Self {
        Self { index, kind: PhantomData }
    }

    fn index(&self) -> usize {
        self.index
    }
}

enum User {}
enum Project {}

fn main() {
    let user = Id::<User>::new(3);
    let project = Id::<Project>::new(3);
    assert_eq!(user.index(), project.index());
}
