use std::hint::black_box;
use std::time::{Duration, Instant};

fn iterator_sum(values: &[u64]) -> u64 {
    values.iter().copied()
        .filter(|value| value & 1 == 0)
        .fold(0, u64::wrapping_add)
}

fn loop_sum(values: &[u64]) -> u64 {
    let mut sum = 0_u64;
    for &value in values {
        if value & 1 == 0 {
            sum = sum.wrapping_add(value);
        }
    }
    sum
}

fn measure(operation: fn(&[u64]) -> u64, input: &[u64]) -> Duration {
    let start = Instant::now();
    let mut result = 0_u64;
    for _ in 0..64 {
        result ^= operation(black_box(input));
        black_box(result);
    }
    start.elapsed()
}

fn median(mut samples: Vec<Duration>) -> Duration {
    samples.sort();
    samples[samples.len() / 2]
}

fn main() {
    let input: Vec<u64> = (0..2_000).collect();
    assert_eq!(iterator_sum(&input), loop_sum(&input));
    for _ in 0..4 {
        black_box(iterator_sum(black_box(&input)));
        black_box(loop_sum(black_box(&input)));
    }
    let mut iterator = Vec::new();
    let mut explicit = Vec::new();
    for round in 0..11 {
        if round & 1 == 0 {
            iterator.push(measure(iterator_sum, &input));
            explicit.push(measure(loop_sum, &input));
        } else {
            explicit.push(measure(loop_sum, &input));
            iterator.push(measure(iterator_sum, &input));
        }
    }
    println!("iterator median {:?}", median(iterator));
    println!("loop median {:?}", median(explicit));
}
