#[derive(Debug, PartialEq, Eq)]
enum RejectReason {
    Full,
    Closed,
}

#[derive(Debug)]
struct Rejected<T> {
    reason: RejectReason,
    value: T,
}

struct Queue<T> {
    values: Vec<T>,
    limit: usize,
    closed: bool,
}

impl<T> Queue<T> {
    fn try_push(&mut self, value: T) -> Result<(), Rejected<T>> {
        let reason = if self.closed {
            Some(RejectReason::Closed)
        } else if self.values.len() >= self.limit {
            Some(RejectReason::Full)
        } else {
            None
        };

        if let Some(reason) = reason {
            Err(Rejected { reason, value })
        } else {
            self.values.push(value);
            Ok(())
        }
    }
}

fn main() {
    let mut queue = Queue {
        values: Vec::new(), limit: 0, closed: false,
    };
    let rejected = queue.try_push(String::from("job")).unwrap_err();
    assert_eq!(rejected.reason, RejectReason::Full);
    assert_eq!(rejected.value, "job");
}
