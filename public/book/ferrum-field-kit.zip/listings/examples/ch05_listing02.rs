fn borrow_words<'a>(words: Vec<&'static str>) -> Vec<&'a str> {
    words
}

fn main() {
    let words = vec!["red", "green", "blue"];
    let shortened = borrow_words(words);
    assert_eq!(shortened.len(), 3);
}
