use std::ffi::{CStr, CString};

fn main() {
    let owned = CString::new("worker-ready").unwrap();
    let borrowed = owned.as_ptr();
    // SAFETY: owned remains alive and the bytes remain unchanged.
    let view = unsafe { CStr::from_ptr(borrowed) };
    assert_eq!(view.to_bytes(), b"worker-ready");

    let transferred = owned.into_raw();
    // A foreign owner may retain transferred under an agreed protocol.
    // SAFETY: This is the exact pointer from into_raw, returned once,
    // with its terminating nul and string length preserved.
    let recovered = unsafe { CString::from_raw(transferred) };
    assert_eq!(recovered.to_str().unwrap(), "worker-ready");
}
