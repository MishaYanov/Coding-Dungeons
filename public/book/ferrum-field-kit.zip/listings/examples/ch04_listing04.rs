struct Sample {
    value: i64,
}

fn with_sample<F, R>(value: i64, inspect: F) -> R
where
    F: for<'a> FnOnce(&'a Sample) -> R,
{
    let sample = Sample { value };
    inspect(&sample)
}

fn main() {
    let doubled = with_sample(21, |sample| sample.value * 2);
    assert_eq!(doubled, 42);
}
