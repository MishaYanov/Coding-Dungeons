struct Label<'source> {
    text: &'source str,
}

impl<'source> Label<'source> {
    fn text(&self) -> &'source str {
        self.text
    }
}

fn main() {
    let source = String::from("persistent source");
    let text;
    {
        let label = Label { text: &source };
        text = label.text();
    }
    assert_eq!(text, "persistent source");
}
