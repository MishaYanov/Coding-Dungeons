use std::thread;

fn main() {
    let owned = String::from("move this allocation");
    let length = thread::spawn(move || owned.len())
        .join()
        .unwrap();
    assert_eq!(length, 20);

    let values = vec![2_u64, 4, 6, 8];
    thread::scope(|scope| {
        let left = scope.spawn(|| values[..2].iter().sum::<u64>());
        let right = scope.spawn(|| values[2..].iter().sum::<u64>());
        assert_eq!(left.join().unwrap() + right.join().unwrap(), 20);
    });
    assert_eq!(values.len(), 4);
}
