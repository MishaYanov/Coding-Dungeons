use std::cell::RefCell;
use std::rc::Rc;

type Listener = Rc<dyn Fn()>;

#[derive(Default)]
struct Bus {
    listeners: RefCell<Vec<Listener>>,
}

impl Bus {
    fn subscribe(&self, listener: Listener) {
        self.listeners.borrow_mut().push(listener);
    }

    fn emit(&self) {
        let snapshot = self.listeners.borrow().clone();
        for listener in snapshot {
            listener();
        }
    }
}

fn main() {
    let bus = Rc::new(Bus::default());
    let weak_bus = Rc::downgrade(&bus);
    bus.subscribe(Rc::new(move || {
        if let Some(bus) = weak_bus.upgrade() {
            bus.subscribe(Rc::new(|| println!("later listener")));
        }
    }));
    bus.emit();
    assert_eq!(bus.listeners.borrow().len(), 2);
}
