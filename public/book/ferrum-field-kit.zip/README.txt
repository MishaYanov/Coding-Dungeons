THE FERRUM EXPEDITION
Understanding Rust Campaign Edition

Open the campaign PDF and begin at the World Map on page 6.
Choose Architect, Warden, Delver, or Pathfinder, or explore all 42 levels.

The PDF contains clickable routes and a fillable quest log.
It does not run your Rust code or automatically award XP.
Save a personal copy to retain form edits in a compatible PDF reader.
Use campaign/Quest_Journal.txt if you prefer an ordinary editable text file.

CORE MASTERY
Scout 20 XP: predict and inspect a worked example.
Forge 40 XP: produce the boss artifact and satisfy the win conditions.
Explain 40 XP: record the owner, invariant, failure path, and tradeoff.
Side 25 XP: complete the optional harder variation.

CONTENTS
campaign/Routes.json          The four suggested paths
campaign/Encounters.json      Missions without hints/debriefs
campaign/Quest_Journal.txt    Editable evidence and progress log
campaign/Vault.json           Hints and debriefs; open when wanted
campaign/Branching_Rooms.json  Three optional decision encounters
listings/                    Original book examples and validation record

LEVEL AND LISTING NUMBERS
The original Chapter N is now Level N. Listing 24.3 remains Listing 24.3.
Source filenames retain chNN_listingXX so existing references stay useful.
These listings match the accompanying edition of the book.
See listings/README.txt and listings/validation.json for compiler and test results.

Check an accepted unit from the extracted archive:
rustc --edition=2024 --crate-type=lib --emit=metadata listings/examples/ch09_listing01.rs

Run a complete unit that defines main:
rustc --edition=2024 listings/examples/ch38_listing01.rs -o example.exe
./example.exe

Rejected units are intentionally noncompiling. Sketches need their stated context.
The Vault is separate so opening the journal does not reveal boss answers.
