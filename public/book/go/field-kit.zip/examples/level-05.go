package main

import (
	"fmt"
	"sort"
)

func main() {
	counts := map[string]int{}
	for _, crate := range []string{"ink", "rope", "ink"} {
		counts[crate]++
	}
	keys := make([]string, 0, len(counts))
	for key := range counts {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	for _, key := range keys {
		fmt.Println(key, counts[key]) // ink 2, then rope 1
	}
}
