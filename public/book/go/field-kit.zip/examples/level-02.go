package main

import (
	"fmt"
	"strconv"
	"strings"
)

func main() {
	count, err := strconv.Atoi(strings.TrimSpace(" 12 "))
	if err != nil {
		fmt.Println("Unreadable ledger:", err)
		return
	}
	fmt.Println(count + 1) // 13
}
