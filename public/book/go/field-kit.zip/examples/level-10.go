package main

import (
	"errors"
	"fmt"
)

func clamp(value, low, high int) (int, error) {
	if low > high {
		return 0, errors.New("invalid bounds")
	}
	return min(max(value, low), high), nil
}

func main() {
	fmt.Println(clamp(14, 0, 10)) // 10 <nil>
}

/*
package main

import "testing"

func TestClamp(t *testing.T) {
	cases := []struct {
		name                   string
		value, low, high, want int
	}{
		{"below", -1, 0, 10, 0},
		{"inside", 4, 0, 10, 4},
		{"above", 14, 0, 10, 10},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			got, err := clamp(tc.value, tc.low, tc.high)
			if err != nil || got != tc.want {
				t.Fatalf("got %d, %v; want %d, nil", got, err, tc.want)
			}
		})
	}
}
*/
