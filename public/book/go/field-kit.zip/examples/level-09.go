package main

import (
	"errors"
	"fmt"
)

var ErrSealed = errors.New("gate is sealed")

func openGate(name string, hasKey bool) error {
	if hasKey {
		return nil
	}
	return fmt.Errorf("open %s: %w", name, ErrSealed)
}

func main() {
	err := openGate("north", false)
	fmt.Println(err)
	fmt.Println(errors.Is(err, ErrSealed)) // true
}
