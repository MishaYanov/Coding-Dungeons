package main

import (
	"encoding/json"
	"fmt"
)

type Hero struct {
	Name string `json:"name"`
	XP   int    `json:"xp"`
}

func main() {
	var h Hero
	err := json.Unmarshal([]byte(`{"name":"Mira","xp":5}`), &h)
	if err != nil {
		fmt.Println(err)
		return
	}
	fmt.Println(h.Name, h.XP) // Mira 5
}
