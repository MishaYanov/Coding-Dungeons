package main

import "fmt"

type Hero struct {
	Name string
	XP   int
}

func (h *Hero) Earn(amount int) {
	h.XP += amount
}

func (h Hero) Label() string {
	return fmt.Sprintf("%s (%d XP)", h.Name, h.XP)
}

func main() {
	h := Hero{Name: "Mira"}
	h.Earn(5)
	fmt.Println(h.Label()) // Mira (5 XP)
}
