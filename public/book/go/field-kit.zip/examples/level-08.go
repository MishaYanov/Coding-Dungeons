package main

import (
	"fmt"
	"io"
	"strings"
)

func ReadName(r io.Reader) (string, error) {
	bytes, err := io.ReadAll(r)
	if err != nil {
		return "", err
	}
	return strings.TrimSpace(string(bytes)), nil
}

func main() {
	name, err := ReadName(strings.NewReader("  Mira  "))
	fmt.Println(name, err) // Mira <nil>

	var p *strings.Reader
	var r io.Reader = p
	fmt.Println(p == nil, r == nil) // true false
}
