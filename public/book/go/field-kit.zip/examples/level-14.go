package main

import (
	"errors"
	"fmt"
	"sync"
)

type Result struct {
	Value int
	Err   error
}

func dispatch(jobs []func() (int, error), limit int) ([]Result, error) {
	if limit < 1 {
		return nil, errors.New("limit must be positive")
	}
	results := make([]Result, len(jobs))
	indexes := make(chan int)

	var workers sync.WaitGroup
	for range min(limit, len(jobs)) {
		workers.Go(func() {
			for i := range indexes {
				value, err := jobs[i]()
				results[i] = Result{Value: value, Err: err}
			}
		})
	}
	for i := range jobs {
		indexes <- i
	}
	close(indexes)
	workers.Wait()
	return results, nil
}

func main() {
	jobs := []func() (int, error){
		func() (int, error) { return 8, nil },
		func() (int, error) { return 0, errors.New("broken signal") },
		func() (int, error) { return 13, nil },
	}
	results, err := dispatch(jobs, 2)
	fmt.Println(results, err)
	// [{8 <nil>} {0 broken signal} {13 <nil>}] <nil>
}
