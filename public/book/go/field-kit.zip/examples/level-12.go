package main

import (
	"context"
	"fmt"
	"io"
)

func waitForRune(ctx context.Context, signals <-chan string) (string, error) {
	if err := ctx.Err(); err != nil {
		return "", err
	}
	select {
	case <-ctx.Done():
		return "", ctx.Err()
	case signal, ok := <-signals:
		if !ok {
			return "", io.EOF
		}
		return signal, nil
	}
}

func main() {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	signals := make(chan string, 1)
	signals <- "north"
	fmt.Println(waitForRune(ctx, signals)) // north <nil>
	cancel()
	fmt.Println(waitForRune(ctx, signals)) // context canceled
}
