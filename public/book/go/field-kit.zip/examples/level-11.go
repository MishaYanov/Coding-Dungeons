package main

import "fmt"

func squares(nums []int) <-chan int {
	out := make(chan int)
	go func() {
		defer close(out)
		for _, n := range nums {
			out <- n * n
		}
	}()
	return out
}

func main() {
	for n := range squares([]int{2, 3, 4}) {
		fmt.Println(n) // 4, then 9, then 16
	}
}
