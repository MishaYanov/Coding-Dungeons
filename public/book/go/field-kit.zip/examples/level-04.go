package main

import "fmt"

func main() {
	stock := []string{"rope", "torch"}
	front := stock[:1]
	front = append(front, "map")
	fmt.Println(stock) // [rope map]

	owned := make([]string, len(stock))
	copy(owned, stock)
	owned[0] = "ink"
	fmt.Println(stock[0], owned[0]) // rope ink
}
