package main

import "fmt"

func summarize(states []string) (int, int) {
	ready, blocked := 0, 0
	for _, state := range states {
		switch state {
		case "ready":
			ready++
		case "blocked":
			blocked++
		}
	}
	return ready, blocked
}

func main() {
	fmt.Println(summarize([]string{"ready", "blocked", "ready"})) // 2 1
}
