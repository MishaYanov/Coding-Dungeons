package main

import (
	"fmt"
	"strconv"
)

func mapValues[T, U any](items []T, transform func(T) U) []U {
	result := make([]U, len(items))
	for i, item := range items {
		result[i] = transform(item)
	}
	return result
}

func main() {
	labels := mapValues([]int{2, 3, 4}, strconv.Itoa)
	fmt.Printf("%q\n", labels) // ["2" "3" "4"]
}
