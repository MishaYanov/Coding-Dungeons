package main

import (
	"fmt"
	"strings"
)

func main() {
	raw := "  Ada  "
	name := strings.ToUpper(strings.TrimSpace(raw))
	var visits int
	visits++
	fmt.Println(name, visits) // ADA 1
}
