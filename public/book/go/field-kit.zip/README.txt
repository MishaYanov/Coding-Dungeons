Ferrum World 4 / Go
Go: The Relay Guild

With Go installed, run a worked example with go run examples/level-01.go.

Use the starter files to try each challenge. The book has hints, debriefs, and side quests.
