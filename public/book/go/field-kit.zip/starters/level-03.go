package main

func isReady(states []string) bool {
	// Find a state that blocks departure.
	return false
}

func main() {}
