package main

type Hero struct {
	Name string
	XP   int
}

func NewHero(raw string) (Hero, error) {
	// Normalize and validate the name before constructing a hero.
	return Hero{Name: raw}, nil
}

func main() {}
