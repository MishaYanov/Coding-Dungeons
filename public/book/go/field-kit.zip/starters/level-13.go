package main

func mapValues[T, U any](items []T, transform func(T) U) []U {
	// Allocate a result and apply transform once for each item.
	return []U{}
}

func main() {}
