package main

func badge(raw string) string {
	// Trim the recruit name, then uppercase it.
	return raw
}

func main() {}
