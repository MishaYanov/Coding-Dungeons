package main

func squareAll(nums []int) []int {
	// Start a sender, drain its channel, and collect results.
	return []int{}
}

func main() {}
