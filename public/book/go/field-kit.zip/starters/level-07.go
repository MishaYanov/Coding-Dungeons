package main

type Hero struct {
	Name string `json:"name"`
	XP   int    `json:"xp"`
}

func decodeHero(raw string) (Hero, error) {
	// Decode into a local Hero, then validate its fields.
	return Hero{}, nil
}

func main() {}
