package main

func clamp(value, low, high int) (int, error) {
	// Validate the interval and handle both boundaries.
	return value, nil
}

func main() {}
