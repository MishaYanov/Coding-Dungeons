package main

import "context"

func waitForRune(ctx context.Context, signals <-chan string) (string, error) {
	// Check cancellation and wait on both channels.
	return "", nil
}

func main() {}
