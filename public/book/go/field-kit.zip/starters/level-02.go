package main

func parseCount(raw string) (int, error) {
	// Parse, check the error, then validate the count.
	return 0, nil
}

func main() {}
