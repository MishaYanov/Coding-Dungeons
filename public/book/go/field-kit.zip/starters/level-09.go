package main

import "errors"

var ErrSealed = errors.New("gate is sealed")

func openGate(name string, hasKey bool) error {
	// Include the gate name and preserve the sentinel on failure.
	return nil
}

func main() {}
