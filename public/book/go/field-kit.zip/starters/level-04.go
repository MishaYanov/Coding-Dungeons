package main

func withTag(tags []string, tag string) []string {
	// Allocate independent storage for every returned tag.
	return append(tags, tag)
}

func main() {}
