package main

func tally(items []string) map[string]int {
	// Count nonempty keys.
	return map[string]int{}
}

func main() {}
