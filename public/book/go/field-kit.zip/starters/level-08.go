package main

import "io"

func ReadName(r io.Reader) (string, error) {
	// Read from r, then validate the trimmed name.
	return "", nil
}

func main() {}
