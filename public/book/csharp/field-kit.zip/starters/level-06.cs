using System;
using System.Collections.Generic;

var orders = new List<string> { "north", "east" };
// Remove the closed route, then add the new one.
Console.WriteLine(string.Join(", ", orders));
