using System;

var cases = new[] { (-1, 0), (0, 0), (3, 3), (5, 5), (6, 5) };
foreach (var (input, expected) in cases)
{
    if (Clamp(input) != expected)
    {
        Console.WriteLine($"A check failed at {input}.");
        return;
    }
}
Console.WriteLine($"{cases.Length} checks passed");

static int Clamp(int input) => 5; // Replace this rule.
