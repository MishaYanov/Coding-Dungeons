using System;

Console.WriteLine(MountingScrews(4));

static int MountingScrews(int lanterns)
{
    // Guard the input, then calculate the result.
    return 0;
}
