using System;
using System.Globalization;

int count = 3;
decimal price = 1.25m;
decimal total = count + price; // Correct the rule.
Console.WriteLine(total.ToString("F2",
    CultureInfo.InvariantCulture));
