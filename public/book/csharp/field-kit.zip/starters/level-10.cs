using System;
using System.Globalization;

IPriceRule rule = new FlatRate();
// Define DiscountRate and choose it here.
Console.WriteLine(rule.Quote(4).ToString("F2",
    CultureInfo.InvariantCulture));

interface IPriceRule
{
    decimal Quote(int count);
}

sealed class FlatRate : IPriceRule
{
    public decimal Quote(int count) => count * 1.50m;
}
