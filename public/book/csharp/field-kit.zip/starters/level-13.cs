#nullable enable
using System;
using System.Text.Json;

string json = """{"Code":"N-02","Count":4}""";
var manifest = JsonSerializer.Deserialize<Manifest>(json);
// Validate the result before using its fields.
Console.WriteLine("Invalid manifest");

record Manifest(string Code, int Count);
