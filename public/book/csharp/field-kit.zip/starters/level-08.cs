#nullable enable
using System;

Console.WriteLine(Label("  Gate  "));

static string Label(string? input)
{
    // Normalize a provided name and handle a missing one.
    return "Unlabeled";
}
