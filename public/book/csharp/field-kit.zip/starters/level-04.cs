using System;

int[] counts = { 0, 4, 0, 5 };
int empty = 0;
// Count the shelves whose value is zero.
Console.WriteLine($"Empty shelves: {empty}");
