using System;
using System.IO;

try
{
    using var reader = new StringReader("9");
    int count = 0; // Parse the line.
    Console.WriteLine($"Count: {count}");
}
catch (FormatException)
{
    Console.WriteLine("Invalid count");
}
