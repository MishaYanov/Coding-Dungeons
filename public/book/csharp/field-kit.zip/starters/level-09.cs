using System;

var original = new Order("A-12", 2);
var changed = original;
// Make a copy with a different count.
Console.WriteLine($"{original.Count} -> {changed.Count}");

record Order(string Code, int Count);
