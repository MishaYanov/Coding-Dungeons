#nullable enable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;

string json = """
    [{"Code":"Wick","Count":2},{"Code":"Glass","Count":0}]
    """;
Console.WriteLine(Report(json));

static string Report(string json)
{
    var rows = JsonSerializer.Deserialize<Shelf[]>(json)
        ?? throw new JsonException("Expected a shelf list.");
    // Validate the shelves, then build the low-stock summary.
    return "";
}

record Shelf(string Code, int? Count);
