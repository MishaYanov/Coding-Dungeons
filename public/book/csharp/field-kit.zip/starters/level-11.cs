using System;
using System.Collections.Generic;
using System.Linq;

var counts = new List<int> { 5, 1, 4, 3 };
// Shape the result with Where, OrderBy, and Select.
var result = counts.ToList();
Console.WriteLine(string.Join(", ", result));
