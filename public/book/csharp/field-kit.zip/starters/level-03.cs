using System;

string text = "3";
// Parse text, then check the size of the count.
Console.WriteLine($"Invalid: {text}");
