using System;
using System.Threading.Tasks;

Task<int> east = ReadAsync(4);
Task<int> west = ReadAsync(7);
// Await both results and print their sum.
await Task.WhenAll(east, west);
Console.WriteLine(0);

static async Task<int> ReadAsync(int count)
{
    await Task.Yield();
    return count;
}
