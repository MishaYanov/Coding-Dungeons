using System;

string command = args.Length == 0 ? "summary" : args[0];
switch (command)
{
    case "summary":
        Console.WriteLine("Workshop summary");
        return 0;
    // Add the stock command here.
    default:
        Console.Error.WriteLine("Unknown command.");
        return 2;
}
