using System;
using System.Collections.Generic;

var stock = new Dictionary<string, int>(
    StringComparer.OrdinalIgnoreCase);
stock["wick"] = 2;
stock["glass"] = 0;
string key = "WICK";
// Look up key and distinguish missing from zero.
Console.WriteLine($"Unknown fixture: {key}");
