using System;

string apprentice = "Jo";
Console.WriteLine(apprentice);
// Include the apprentice variable in the greeting.
