Ferrum World 3 / C# and .NET
C# and .NET: The Lantern Workshop

Install the .NET 10 SDK and run:
dotnet run --file examples/level-01.cs --property:PublishAot=false
The option skips native publishing tools. Run one file at a time. The examples only use the standard library.

Use the starter files to try each challenge. The book has hints, debriefs, and side quests.
