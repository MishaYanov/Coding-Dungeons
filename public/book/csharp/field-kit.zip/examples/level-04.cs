using System;

int[] counts = { 0, 2, 4, 1 };
int ready = 0;

foreach (int count in counts)
{
    if (count >= 2)
    {
        ready++;
    }
}
Console.WriteLine($"Ready shelves: {ready}");
