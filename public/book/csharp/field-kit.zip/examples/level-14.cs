using System;
using System.Threading.Tasks;

Task<int> east = ReadAsync(4);
Task<int> west = ReadAsync(7);
int[] values = await Task.WhenAll(east, west);
Console.WriteLine($"{values[0]} + {values[1]}");

static async Task<int> ReadAsync(int count)
{
    await Task.Yield();
    return count;
}
