using System;
using System.IO;

try
{
    using var reader = new StringReader("five");
    int count = int.Parse(reader.ReadLine() ?? "");
    Console.WriteLine($"Count: {count}");
}
catch (FormatException)
{
    Console.WriteLine("The ledger count is not a whole number.");
}
