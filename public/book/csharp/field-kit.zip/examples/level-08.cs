#nullable enable
using System;

Console.WriteLine(Label("   "));

static string Label(string? input)
{
    string? cleaned = input?.Trim();
    return string.IsNullOrEmpty(cleaned) ? "Unlabeled" : cleaned;
}
