using System;

var original = new Lantern("N-01", 5);
var upgraded = original with { Watts = 8 };
Console.WriteLine($"{original.Watts} -> {upgraded.Watts}");

record Lantern(string Code, int Watts);
