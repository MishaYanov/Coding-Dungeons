using System;
using System.Collections.Generic;

var stock = new Dictionary<string, int>(
    StringComparer.OrdinalIgnoreCase);
stock["glass"] = 0;

if (stock.TryGetValue("GLASS", out int count))
{
    Console.WriteLine($"Known stock: {count}");
}
else
{
    Console.WriteLine("Unknown fixture");
}
