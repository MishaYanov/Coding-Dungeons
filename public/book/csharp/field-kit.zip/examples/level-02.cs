using System;
using System.Globalization;

int lamps = 5;
int shelves = 2;
int full = lamps / shelves;
decimal average = (decimal)lamps / shelves;
string display = average.ToString("F1", CultureInfo.InvariantCulture);
Console.WriteLine($"{full} whole, {display} average");
