#nullable enable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;

string sample = """
    [{"Code":"Wick","Count":2},{"Code":"Glass","Count":0}]
    """;
string report = Report(sample);
if (report != "Glass, Wick" || Report("[]") != "")
{
    throw new Exception("A report check failed.");
}
Console.WriteLine(report);

static string Report(string json)
{
    var rows = JsonSerializer.Deserialize<Shelf[]>(json)
        ?? throw new JsonException("Expected a shelf list.");
    var codes = new HashSet<string>(StringComparer.Ordinal);
    foreach (var row in rows)
    {
        if (row is null || string.IsNullOrWhiteSpace(row.Code)
            || row.Count is null or < 0 || !codes.Add(row.Code))
        {
            throw new JsonException("Invalid shelf.");
        }
    }
    var low = rows.Where(row => row.Count is < 3)
        .Select(row => row.Code)
        .OrderBy(code => code, StringComparer.Ordinal);
    return string.Join(", ", low);
}

record Shelf(string Code, int? Count);
