using System;

string apprentice = "Mira";
Console.WriteLine($"Lantern lit for {apprentice}!");
