using System;

string text = " 12 ";
bool parsed = int.TryParse(text, out int count);
if (parsed && count > 0)
{
    Console.WriteLine($"Accepted {count}");
}
else
{
    Console.WriteLine("Use a positive whole number.");
}
