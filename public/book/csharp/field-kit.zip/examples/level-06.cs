using System;
using System.Collections.Generic;

var orders = new List<string> { "north", "east" };
orders.Add("west");
orders.Remove("east");
Console.WriteLine(string.Join(", ", orders));
