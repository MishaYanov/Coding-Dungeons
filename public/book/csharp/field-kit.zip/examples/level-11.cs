using System;
using System.Collections.Generic;
using System.Linq;

var counts = new List<int> { 1, 3, 5 };
var ready = counts.Where(n => n >= 3);
var snapshot = ready.ToList();
counts.Add(7);
Console.WriteLine($"{snapshot.Count} then {ready.Count()}");
