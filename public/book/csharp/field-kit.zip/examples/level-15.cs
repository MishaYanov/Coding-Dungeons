using System;
using System.Threading;
using System.Threading.Tasks;

using var recall = new CancellationTokenSource();
recall.Cancel();
try
{
    Console.WriteLine(await ReadAsync(recall.Token));
}
catch (OperationCanceledException)
    when (recall.IsCancellationRequested)
{
    Console.WriteLine("Reading canceled.");
}

static async Task<int> ReadAsync(CancellationToken token)
{
    await Task.Yield();
    token.ThrowIfCancellationRequested();
    return 5;
}
