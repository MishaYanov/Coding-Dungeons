using System;

var cases = new[] { (-1, 0), (0, 0), (3, 3), (5, 5), (6, 5) };
foreach (var (input, expected) in cases)
{
    int actual = Clamp(input);
    if (actual != expected)
    {
        throw new Exception($"For {input}, expected {expected}.");
    }
}
Console.WriteLine($"{cases.Length} checks passed");

static int Clamp(int input) => Math.Clamp(input, 0, 5);
