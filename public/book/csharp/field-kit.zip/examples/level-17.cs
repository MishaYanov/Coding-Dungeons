using System;

string command = args.Length == 0 ? "summary" : args[0];
switch (command)
{
    case "summary":
        Console.WriteLine("Workshop summary");
        return 0;
    case "help":
        Console.WriteLine("Commands: summary, help");
        return 0;
    default:
        Console.Error.WriteLine("Unknown command.");
        return 2;
}
