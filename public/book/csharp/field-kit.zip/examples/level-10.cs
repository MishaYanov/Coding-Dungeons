using System;
using System.Globalization;

IPriceRule rule = new FlatRate();
string result = rule.Quote(4).ToString("F2",
    CultureInfo.InvariantCulture);
Console.WriteLine(result);

interface IPriceRule
{
    decimal Quote(int count);
}

sealed class FlatRate : IPriceRule
{
    public decimal Quote(int count) => count * 1.50m;
}
