#nullable enable
using System;
using System.Text.Json;

var original = new Manifest("N-01", 3);
string json = JsonSerializer.Serialize(original);
Manifest? copy = JsonSerializer.Deserialize<Manifest>(json);

if (copy is null || string.IsNullOrWhiteSpace(copy.Code)
    || copy.Count <= 0)
{
    throw new JsonException("Manifest does not meet the rules.");
}
Console.WriteLine($"{copy.Code} x{copy.Count}");

record Manifest(string Code, int Count);
