using System;

Console.WriteLine(FittingsFor(4));

static int FittingsFor(int lanterns)
{
    if (lanterns < 0)
    {
        throw new ArgumentOutOfRangeException(nameof(lanterns));
    }
    return checked(lanterns * 3);
}
